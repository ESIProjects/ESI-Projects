#include "header.h"
#include "display.h"
#include "menus.h"
#include <unistd.h>
#include <windows.h>
#include <MMsystem.h>

int main() {

    /**__TP1-LADOUL-HELLALET-G07__**/
    clrscr();
    system("mode con LINES=40 COLS=160");
    salles classes;
    intro();
    loading_page();
    menu(classes);
    return 0;

    /**_________1-4-2023________**/
}


























