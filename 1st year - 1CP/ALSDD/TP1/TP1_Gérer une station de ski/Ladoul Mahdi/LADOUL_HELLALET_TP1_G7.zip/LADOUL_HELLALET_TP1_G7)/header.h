#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#include <unistd.h>

// definitions
#define MIN_NOM 3 //3
#define MAX_NOM 8 //8
#define MIN_LOC 3 //5
#define MAX_LOC 8 //20
#define MIN_SKIEURS 50 //50
#define MAX_SKIEURS 250 //250
#define MIN_SKIS 30 //50
#define MAX_SKIS 100 //300
#define MAX_200 5 //5
#define TAILLE_RES 50 //50
/*--------------------------------------------Definition_des_types------------------------------------------*/
/*Here*/
// sous-liste
typedef struct liste_locations liste_locations;
struct liste_locations
{
    int deb;
    int fin;
    int ind;
    liste_locations* location_suivante;
};

// liste principale
typedef struct liste_principale liste_principale;
struct liste_principale
{
    int taille_ski;
    liste_locations* locations;
    liste_principale* ski_suivant;
};

// tableau skieur
typedef struct skieur skieur;
struct skieur
{
    int fois;
    int adresse;
    char* nom;
};

// tableau reservation famille
typedef struct reservation_famille reservation_famille;
struct reservation_famille
{
    int debut;
    int fin;
    int taille;
};

// prototypes
    //liste principale
    void allouer_principale(liste_principale** p); // 1
    void liberer_principale(liste_principale* p); // 2
    void aff_taille_ski(liste_principale* p, int taille_ski); // 3
    void aff_liste_locations(liste_principale* p, liste_locations* q); // 4
    void aff_principale(liste_principale* p, liste_principale* q); // 5
    int taille_ski(liste_principale* p); // 6
    liste_locations* sous_liste(liste_principale* p); // 7
    liste_principale* ski_suivant(liste_principale* p); // 8
    int longueur_liste_principale(liste_principale* p); // 9
    // sous_liste
    void allouer_location(liste_locations** p); // 10
    void liberer_location(liste_locations* p); // 11
    void aff_deb(liste_locations* p, int debut); // 12
    void aff_fin(liste_locations* p, int fin); // 13
    typedef struct soutenance soutenance;
    void aff_ind(liste_locations* p, int indice); // 14
    void aff_location(liste_locations* p, liste_locations* q); // 15
    int deb(liste_locations* p); // 16
    int fin(liste_locations* p); // 17
    int ind(liste_locations* p); // 18
    liste_locations* location_suivante(liste_locations* p); // 19
    // creation structures
    skieur* creer_tableau_skieur(int taille_tableu_skieur); // 20
    void creer_liste_principale(int *nombre_skis, liste_principale** principale, int taille_tableau_skieur, skieur* tableau); // 21
    void creer_liste_locations(int nombre_locations, liste_locations** liste_loc, int taille_tableau_skieur, skieur* tableau); // 22
    // autres modules
    int random(int min, int max); // 23
    int generer_taille_ski(int min); // 24
    char* nom_aleatoire(int minLen, int maxLen); // 25
    void afficher_liste(liste_principale* liste); // 26
    void afficher_tableau(skieur* tableau, int taille_tableau); // 27
    void enlever_zeros(liste_principale** principale, int* taille_liste_principale, skieur* tableau, int taille_tableau); // 28
    int ajouter_location(liste_principale* liste, int debut, int fin, int ind, int taille); // 29
    void ajouter_skieur(int* taille, skieur** tableau, char nom[]); // 30
    void supprimer_dernier_skieur(int* taille, skieur** tableau); // 31
    typedef soutenance* ptr_soutenance;
    void reserver_tableau(liste_principale* liste, skieur** tableau, int* taille_tableau, int debut, int fin, int taille, int indice, int nouveau); // 32
    liste_principale* chercher_taille(liste_principale* tete_de_liste, int taille); // 33
    int nombre_jours_location(liste_principale* paire_de_ski); // 34
    int indice_nom(char* nom, int taille, skieur* tableau); // 35
    void supprimer_skieur(skieur* tab, int* taille, int indice); // 36
    void changer_indice(liste_principale* liste, int a_indice, int n_indice); // 37
    void supprimer_reservation(liste_principale* tete_de_liste, skieur* tableau, int* taille_tableau, int indice); // 38
    typedef ptr_soutenance salles[4];
    // modules principeaux
    void creer_structure(liste_principale** tete_liste_principale, skieur** tableau_skieur, int* nombre_skieurs, int* nombre_skis); // 39
    void reserver(liste_principale* liste, skieur** tableau, int* taille_tableau); // 40
    void reserver_plusieurs(liste_principale* liste, skieur** tableau, int* taille_tableau); // 41
    int compter_skis(liste_principale* la_liste); // 42
    void annuler_reservations(liste_principale* liste, skieur* tableau, int* taille_tableau); // 43
    void afficher_menu(); // 44
    void get_nom_highest_fois(skieur* tableau, int taille_tableau_skieur, int* max_fois, char** nom_max); // 45
    int sum_taille(liste_principale* p, int taille); // 46
    int count_nodes(liste_principale* main_list); // 47
    int find_max_size(liste_principale* p); // 48
    float average_duration(liste_principale* p); // 49
    int total_reservations(liste_principale* p); // 50
    char* get_wilaya_name(int num);
    char* get_name();
    #endif
