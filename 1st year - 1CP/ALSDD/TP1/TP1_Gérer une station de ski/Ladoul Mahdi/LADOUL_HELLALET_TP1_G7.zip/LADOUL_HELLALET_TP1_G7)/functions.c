#include "header.h"
#include "display.h"
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include "menus.h"

// machine abstraite

    // liste principale
    void allouer_principale(liste_principale** p)
    {
        *p = malloc(sizeof(liste_principale));
    }
    void liberer_principale(liste_principale* p)
    {
        free(p);
    }
    void aff_taille_ski(liste_principale* p, int taille_ski)
    {
        p->taille_ski = taille_ski;
    }
    void aff_liste_locations(liste_principale* p, liste_locations* q)
    {
        p->locations = q;
    }
    void aff_principale(liste_principale* p, liste_principale* q)
    {
        p->ski_suivant = q;
    }
    int taille_ski(liste_principale* p)
    {
        return p->taille_ski;
    }
    liste_locations* sous_liste(liste_principale* p)
    {
        return p->locations;
    }
    liste_principale* ski_suivant(liste_principale* p)
    {
        return p->ski_suivant;
    }
    int longueur_liste_principale(liste_principale* p)
    {
        int i = 0;
        while (p != NULL)
        {
            i++;
            p = ski_suivant(p);
        }
        return i;
    }

    // la sous-liste
    void allouer_location(liste_locations** p)
    {
        *p = malloc(sizeof(liste_locations));
    }
    void liberer_location(liste_locations* p)
    {
        free(p);
    }
    void aff_deb(liste_locations* p, int debut)
    {
        p->deb = debut;
    }
    void aff_fin(liste_locations* p, int fin)
    {
        p->fin = fin;
    }
    void aff_ind(liste_locations* p, int indice)
    {
        p->ind = indice;
    }
    void aff_location(liste_locations* p, liste_locations* q)
    {
        p->location_suivante = q;
    }
    int deb(liste_locations* p)
    {
        return p->deb;
    }
    int fin(liste_locations* p)
    {
        return p->fin;
    }
    int ind(liste_locations* p)
    {
        return p->ind;
    }
    liste_locations* location_suivante(liste_locations* p)
    {
        return p->location_suivante;
    }
//




// creation des structures

    // creation du tableau
    skieur* creer_tableau_skieur(int taille_tableau_skieur)
    {

        skieur *tableau = malloc(taille_tableau_skieur * sizeof(skieur));
        for (int i = 0; i < taille_tableau_skieur; i++)
        {
            char* nom_skieur = nom_aleatoire(3, 8);
            tableau[i].nom = nom_skieur;
            tableau[i].adresse = random(1, 58);
            tableau[i].fois = 0;
        }
        return tableau;
    }



    // creation des listes
        // liste principale
        void creer_liste_principale(int* nombre_skis, liste_principale** principale, int taille_tableau_skieur, skieur* tableau)
        {
            liste_principale* p = NULL;
            liste_principale* q = NULL;
            liste_locations* l;
            int taille_ski,  min_taille=80, i=2, compteur_200=0, compteur_nombre_skis=1;
            taille_ski = generer_taille_ski(min_taille);
            allouer_principale(&q);
            aff_taille_ski(q, taille_ski);
            *principale = q;
            creer_liste_locations(random(MIN_LOC, MAX_LOC), &l, taille_tableau_skieur, tableau);
            aff_liste_locations(q, l);
            while((i<=*nombre_skis) && (compteur_200<MAX_200))
            {
                min_taille = taille_ski + random(0, 1);
                taille_ski = generer_taille_ski(min_taille);
                if (taille_ski == 200) compteur_200++;
                allouer_principale(&p);
                aff_taille_ski(p, taille_ski);
                aff_principale(q, p);
                creer_liste_locations(random(MIN_LOC, MAX_LOC), &l, taille_tableau_skieur, tableau);
                aff_liste_locations(p, l);
                q = p;
                compteur_nombre_skis++;
                i++;
            }
            aff_principale(q, NULL);
            *nombre_skis = compteur_nombre_skis;
        }

        // sous liste
        void creer_liste_locations(int nombre_locations, liste_locations** liste_loc, int taille_tableau_skieur, skieur* tableau)
        {
            liste_locations* p = NULL;
            liste_locations* q = NULL;
            int debut=1, fin=1, i=2;
            debut = fin + random(0, random(5, 30));
            fin = debut + random(0, 10);
            allouer_location(&q);
            aff_deb(q, debut);
            aff_fin(q, fin);
            aff_ind(q, random(0, taille_tableau_skieur-1));
            // incrementer dans le tableau
            tableau[ind(q)].fois++;
            *liste_loc = q;
            //for (int i=2; i<=nombre_locations; i++)
            while ((i <= nombre_locations) && (fin < 151))
            {
                debut = fin + random(1, random(25, 30));
                fin = debut + random(0, 10);
                if (debut > 151) debut = 151;
                if (fin > 151) fin = 151;
                allouer_location(&p);
                aff_deb(p, debut);
                aff_fin(p, fin);
                aff_ind(p, random(0, taille_tableau_skieur-1));
                // incrementer dans le tableau
                tableau[ind(p)].fois++;
                aff_location(q, p);
                q = p;
                i++;
            }
            aff_location(q, NULL);
        }




// autres modules

    // generer un nombre aleatoire
    int random(int min, int max)
    {
        return (rand() % (max - min + 1)) + min;
    }

    // generer une taille de ski (multiple de 5)
    int generer_taille_ski(int min)
    {
        int taille_ski;
        taille_ski = min + random(0, 5);
        taille_ski = taille_ski - (taille_ski % 5);
        if (taille_ski > 200) taille_ski = 200;
        return taille_ski;
    }

    // generer un nom aleatoire
    char* nom_aleatoire(int minLen, int maxLen)
    {
        static const char alphabet[] = "aeiouybcdfghjklmnprstvwxzAEIOUYBCDFGHJKLMNPRSTVWXZ";
        int len = random(minLen, maxLen), i=0;
        char* str = malloc((len + 1) * sizeof(char));
        str[i] = alphabet[random(25, 49)];
        for (i = 1; i < len; i++)
        {
            if ((i % 2)==1)
            {
                str[i] = alphabet[random(0,5)];
            }
            else
            {
                str[i] = alphabet[random(6,24)];
            }

        }
        str[len] = '\0';
        return str;
    }

    // afficher toute la liste
    void afficher_liste(liste_principale* liste)
    {
        liste_principale* pointeur_p = liste;
        int compteur_principale = 1;
        int compteur_location;
                    clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\t\e[34m ____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|                                            |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|          Affichage de la liste             |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\n\n");
        printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
        printf("\t\t\t\t\t\tRemarque :\n\n");
        printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer l'affichage\n\n");
        printf("\t\t\t\t\t\tLe programme va afficher 10 locations a la fois \n");
        printf("\t\t\t\t\t\tExemple: SKI (numero de ski) de taille (taille de ski)\n");
        printf("\t\t\t\t\t\t(numero de location):    (date debut) ---> (date fin)   (indice skieur)\n");
        printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
        getch();
        int hi = 0 ;
        while (pointeur_p != NULL)
        {
            printf("\t\t\t\t\t\tSKI %d de taille %d:\n", compteur_principale, taille_ski(pointeur_p));
            liste_locations* pointeur_l = sous_liste(pointeur_p);
            compteur_location = 1;
            while (pointeur_l != NULL)
            {
                hi++;
                printf("\t\t\t\t\t\t    %2d:     %-3d ---> %3d   (%3d)\n", compteur_location, deb(pointeur_l), fin(pointeur_l), ind(pointeur_l));
                pointeur_l = location_suivante(pointeur_l);
                compteur_location++;
                if ( hi == 10) {
                printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
                getchar();
                hi = 0;
                }
            }

            pointeur_p = ski_suivant(pointeur_p);
            compteur_principale++;
        }
    }

    // afficher le tableau
    void afficher_tableau(skieur* tableau, int taille_tableau)
    {
            clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\t\e[34m ____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|                                            |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|           Affichage de Tableau             |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\n\n");
        printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
        printf("\t\t\t\t\t\tRemarque :\n\n");
        printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer l'affichage \n\n");
        printf("\t\t\t\t\t\tLe programme va afficher 10 clients a la fois \n");
        printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
        getch();
        printf("\t\t\t\t\t\t+-----+------------------+------------------------+------------+\n");
        printf("\t\t\t\t\t\t| Ind |       Nom        |         Wilaya         |    Fois    |\n");
        printf("\t\t\t\t\t\t+-----+------------------+------------------------+------------+\n");
        int atcho = 0;
        for (int i = 0; i < taille_tableau; i++)
        {
            printf("\t\t\t\t\t\t| %-3d | %-16s | %-22s | %10d |\n", i, tableau[i].nom, get_wilaya_name(tableau[i].adresse), tableau[i].fois);
            atcho++;
            if  (atcho == 10) {
                atcho = 0 ;
                getch();
            }
        }
        printf("\t\t\t\t\t\t+-----+------------------+------------------------+------------+\n");
    }

    // enlever les zeros (bien expliquee)
    void enlever_zeros(liste_principale** principale, int* taille_liste_principale, skieur* tableau, int taille_tableau)
    {
        int i=0, deb=1, fin=1, zero=0;
        liste_principale* q = *principale;
        liste_principale* p = NULL;
        liste_locations* l2 = NULL;
        // mettre le pointeur q dans le queue de la liste principale
        while(ski_suivant(q) != NULL)
        {
            q = ski_suivant(q);
        }
        /* allouer un nouveau maillon (ski) etle pointer par p et chainer avec q
        (q devient l'avant dernier et p le dernier) */
        allouer_principale(&p);
        aff_taille_ski(p, 200);
        aff_principale(p, NULL);
        aff_principale(q, p);
        // parcourir le tableau
        while((i<taille_tableau))
        {
            // si on trouve une case fois egale a 0:
            if (tableau[i].fois==0)
            {
                zero=1; // metre le booleen zero a 1 (dire qu'il existe au moins une case fois = 0)
                // creer un maillon (location) pointe par l
                liste_locations* l = NULL;
                allouer_location(&l);
                aff_ind(l, i);
                deb = fin + random(0, 2);
                fin = deb + random(0, 2);
                aff_deb(l, deb);
                aff_fin(l, fin);
                if(l2 == NULL) // si c'est la premiere location
                {
                    // l sera la tete de la liste de locations
                    aff_liste_locations(p, l);
                    l2=l; // l2 est le pointeur du mallon precedent pour chainer avec les nouveaux maillons crees
                }
                else // sinon (des locations ont deja ete crees dans la liste)
                {
                    aff_location(l2, l); // faire le chainage avec le maillon precedaent
                    l2=l; // avancer l2
                }
                tableau[i].fois++;
            }
            i++;
        }
        if (zero==0) // si les zeros n'existent pas
        {

            q->ski_suivant=NULL; // on libere le maillon de p
            liberer_principale(p);
        }
        else
        {
            *taille_liste_principale = *taille_liste_principale + 1;
        }
    }

    // ajouter une location
    int ajouter_location(liste_principale* liste, int debut, int la_fin, int indice, int taille)
    {
        int loc=0;
        liste_principale* pointeur_p = liste;
        liste_locations* pointeur_location_n = NULL;
        allouer_location(&pointeur_location_n);
        aff_deb(pointeur_location_n, debut);
        aff_fin(pointeur_location_n, la_fin);
        aff_ind(pointeur_location_n, indice);
        while ((pointeur_p != NULL) && (loc == 0))
        {
            if (taille_ski(pointeur_p) == taille)
            {
                liste_locations* pointeur_location = sous_liste(pointeur_p);
                liste_locations* pointeur_location_2 = NULL;
                while(((pointeur_location != NULL) || (pointeur_location_2 != NULL)) && (loc == 0))
                {
                    if (pointeur_location_2 == NULL)
                    {
                        if (la_fin < deb(pointeur_location))
                        {
                            aff_location(pointeur_location_n, pointeur_location);
                            aff_liste_locations(pointeur_p, pointeur_location_n);
                            loc=1;
                        }
                    }
                    else if (pointeur_location == NULL)
                    {
                        if (debut > fin(pointeur_location_2))
                        {
                            aff_location(pointeur_location_2, pointeur_location_n);
                            aff_location(pointeur_location_n, NULL);
                            loc=1;
                        }
                    }
                    else
                    {
                        if ((debut > fin(pointeur_location_2)) && (la_fin < deb(pointeur_location)))
                        {
                            aff_location(pointeur_location_2, pointeur_location_n);
                            aff_location(pointeur_location_n, pointeur_location);
                            loc=1;
                        }
                    }
                    pointeur_location_2 = pointeur_location;
                    if (pointeur_location != NULL)
                    {
                        pointeur_location = location_suivante(pointeur_location);
                    }

                }
            }
            pointeur_p = ski_suivant(pointeur_p);
        }
        return loc;
    }

    // ajouter un skieur
    void ajouter_skieur(int* taille, skieur** tableau, char nom[])
    {
        *taille += 1;
        *tableau = (skieur*)realloc(*tableau, (*taille)*sizeof(skieur));
        if (*tableau == NULL)
        {
            printf("\t\t\t\t\t\tErreur de reallocation de memoire.\n\n");
            exit(1);
        }
        (*tableau)[*taille-1].nom = (char*)malloc((strlen(nom)+1)*sizeof(char));
        if ((*tableau)[*taille-1].nom == NULL)
        {
            printf("\t\t\t\t\t\tErreur d'allocation de memoire.\n\n");

            exit(1);
        }
        strcpy((*tableau)[*taille-1].nom, nom);
        do
        {
            printf("\t\t\t\t\t\tDonner le numero de la wilaya du skieur : ");

            scanf("%d", &((*tableau)[*taille-1].adresse));
            printf("\n");
            if (((*tableau)[*taille-1].adresse < 1) || ((*tableau)[*taille-1].adresse > 58))
            {
                printf("\t\t\t\t\t\tWilaya inexistante : \n\n");
            }
        }
        while (((*tableau)[*taille-1].adresse < 1) || ((*tableau)[*taille-1].adresse > 58));
        (*tableau)[*taille-1].fois = 0;
    }

    // supprimer le dernier skieur
    void supprimer_dernier_skieur(int* taille, skieur** tableau)
    {
        if (*taille == 0)
        {
            printf("\t\t\t\t\t\tLe tableau est déjà vide.\n\n");
            return;
        }
        free((*tableau)[*taille-1].nom);
        *taille -= 1;
        *tableau = (skieur*)realloc(*tableau, (*taille)*sizeof(skieur));
        if (*tableau == NULL && *taille > 0)
        {
            printf("\t\t\t\t\t\tErreur de réallocation de mémoire.\n\n");
            exit(1);
        }
    }

    // reserve une paire de ski a partir des informations: indice, debut, fin et taille
    void reserver_tableau(liste_principale* liste, skieur** tableau, int* taille_tableau, int debut, int fin, int taille, int indice, int nouveau)
    {
        int fait=0;
        fait = ajouter_location(liste, debut, fin, indice, taille);
        if (fait)
        {
            printf("\t\t\t\t\t\tReservation realisee avec succes!\n\n");
            (*tableau)[indice].fois++;
        }
        else
        {
            //if ((nouveau == 1) && ((*tableau)[indice].fois == 0) && (*taille_tableau - 1 == indice)) supprimer_dernier_skieur(taille_tableau, tableau);
            printf("\t\t\t\t\t\tReservation impossible!\n\n");
        }
    }

    // donner un pointeur vers la premiere paire de ski d'une certaine taille
    liste_principale* chercher_taille(liste_principale* tete_de_liste, int taille)
    {
        liste_principale* pointeur_p = tete_de_liste;
        int trouver = 0;
        while ((pointeur_p != NULL) && (trouver == 0))
        {
            if (taille_ski(pointeur_p) == taille) trouver = 1;
            else pointeur_p = ski_suivant(pointeur_p);
        }
        if (trouver == 0) pointeur_p = NULL;
        return pointeur_p;
    }

    // donne le nombre de jours de location d'une paire de ski
    int nombre_jours_location(liste_principale* paire_de_ski)
    {
        int compteur=0;
        liste_locations* pointeur_l = sous_liste(paire_de_ski);
        while (pointeur_l != NULL)
        {
            compteur = compteur + (fin(pointeur_l) - deb(pointeur_l) + 1);
            pointeur_l = location_suivante(pointeur_l);
        }
        return compteur;
    }

    // donne l'indice de skieur a partir de son nom (retourne -1 s'il n'existe pas)
    int indice_nom(char* nom, int taille, skieur* tableau)
    {
        for (int i = 0; i < taille; i++)
        {
            if (strcmp(tableau[i].nom, nom) == 0) return i;
        }
        // Si le skieur n'est pas trouve, retourner -1
        return -1;
    }

    // compter le nombre des paires de ski existantes
    int compter_skis(liste_principale* la_liste)
    {
        liste_principale* pointeur_p = la_liste;
        int nombre_de_skis = 0;
        while (pointeur_p != NULL)
        {
            nombre_de_skis += 1;
            pointeur_p = ski_suivant(pointeur_p);
        }
        return nombre_de_skis;
    }

    // supprimer la cese du skieur et mettre la derneire dans sa place
    void supprimer_skieur(skieur* tab, int* taille, int indice)
    {
        if (indice < 0 || indice >= *taille)
        {
        printf("\t\t\t\t\t\tIndice invalide\n\n");
        return;
        }
        free(tab[indice].nom);
        if (indice != *taille-1) {
            tab[indice] = tab[*taille-1];
        }
        *taille -= 1;
    }

    // changer l'indice d'un skieur
    void changer_indice(liste_principale* liste, int a_indice, int n_indice)
    {
        liste_principale* pointeur_p = liste;
        while (pointeur_p != NULL)
        {
            liste_locations* pointeur_l = sous_liste(pointeur_p);
            while (pointeur_l != NULL)
            {
                if (ind(pointeur_l) == a_indice)
                {
                    aff_ind(pointeur_l, n_indice);
                }
                pointeur_l = location_suivante(pointeur_l);
            }
            pointeur_p = ski_suivant(pointeur_p);
        }
    }

    // supprimer le maillon d'une reservation
    void supprimer_reservation(liste_principale* liste, skieur* tableau, int* taille_tableau, int indice)
    {
        liste_principale* pointeur_p = liste;
        while (pointeur_p != NULL)
        {
            liste_locations* pointeur_l = sous_liste(pointeur_p);
            liste_locations* pointeur_l_2 = NULL;
            while (pointeur_l != NULL)
            {
                if (ind(pointeur_l) == indice)
                {
                    if (pointeur_l_2 == NULL)
                    {
                        aff_liste_locations(pointeur_p, location_suivante(pointeur_l));
                        free(pointeur_l);
                        pointeur_l = sous_liste(pointeur_p);
                    }
                    else
                    {
                        aff_location(pointeur_l_2, location_suivante(pointeur_l));
                        free(pointeur_l);
                        pointeur_l = location_suivante(pointeur_l_2);
                    }
                }
                else
                {
                    pointeur_l_2 = pointeur_l ;
                    pointeur_l = location_suivante(pointeur_l);
                }
            }
            pointeur_p = ski_suivant(pointeur_p);
        }
        supprimer_skieur(tableau, taille_tableau, indice);
        changer_indice(liste, *taille_tableau, indice);
    }

// modules principeaux

    // creer toute la structure (listes et tableau)
    void creer_structure(liste_principale** tete_liste_principale, skieur** tableau_skieur, int* nombre_skieurs, int* nombre_skis)
    {
        *tableau_skieur = creer_tableau_skieur(*nombre_skieurs);
        creer_liste_principale(nombre_skis, tete_liste_principale, *nombre_skieurs, *tableau_skieur);
        enlever_zeros(tete_liste_principale, nombre_skis, *tableau_skieur, *nombre_skieurs);
    }

    // reserver une seule paire de ski
    void reserver(liste_principale* liste, skieur** tableau, int* taille_tableau)
    {
        int debut, fin, taille, indice, fait=0, nouveau=0;
        char nom[100];
            dude:clrscr();
            clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\t\e[34m ____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|                                            |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|        Reserver une paire de ski           |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\n\n\n");
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n\n");
              printf("\t\t\t\t\t\tEntrez le nom du skieur : ");
              scanf("%s", nom);
              printf("\n");
                    indice = indice_nom(nom, *taille_tableau, *tableau);
                    do
                    {
                        do
                        {
                            printf("\t\t\t\t\t\tDonner la taille de la paire de ski souhaitee:");
                            scanf("%d", &taille);
                            printf("\n");
                            if (((taille % 5 != 0) || (taille < 80) || (taille > 200))) {printf("\t\t\t\t\t\tTaille indisponible!\n");
                            printf("\n");}
                        } while ((taille % 5 != 0) || (taille < 80) || (taille > 200));
                        if (indice == -1)
                        {
                            nouveau=1;
                            indice = *taille_tableau;
                            ajouter_skieur(taille_tableau, tableau, nom);
                        }
                        do
                        {
                            printf("\t\t\t\t\t\tDonner le jour de debut: ");
                            scanf ("%d", &debut);
                            printf("\n");


                            if ((debut < 1) || (debut > 151)) {printf("\t\t\t\t\t\tDate indisponible!\n\n");

                            }
                        } while ((debut < 1) || (debut > 151));
                        do
                        {
                            printf("\t\t\t\t\t\tDonner le jour de fin:");
                            scanf ("%d", &fin);
                            printf("\n");
                            if ((fin < debut) || (fin > 151)) printf("\t\t\t\t\t\tDate indisponible!\n");
                        } while ((fin < debut) || (fin > 151));
                       fait = ajouter_location(liste, debut, fin, indice, taille);
                        if (fait)
                        {
                            printf("\t\t\t\t\t\tReservation realisee avec succes!\n\n");
                            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");

                            (*tableau)[indice].fois++;
                        }
                        else
                        {
                            if (nouveau == 1) supprimer_dernier_skieur(taille_tableau, tableau);
                            printf("\t\t\t\t\t\tReservation impossible! Reessayer avec des parametres differents?\n\n");
                            do
                            {
                                printf("\t\t\t\t\t\t1.NON        2.OUI               : ");
                                scanf("%d", &fait);
                                printf("\n");

                                if ((fait < 1) || (fait > 2)) printf("\t\t\t\t\t\tChoix incorrect!\n\n");

                            } while ((fait < 1) || (fait > 2));
                            if ( fait ==  2 ) goto dude;
                            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");

                        }
                    } while(fait != 1);
                }

    // reserver des paires de ski
    void reserver_plusieurs(liste_principale* liste, skieur** tableau, int* taille_tableau)
    {
        int nombre_reservations, i, indice, nouveau;
        char nom[100];
        reservation_famille res[TAILLE_RES];
            clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\t\e[34m ____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|                                            |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|       Reserver Des Paires de Ski           |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\n\n\n");
        printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
          printf("\t\t\t\t\t\tEntrez le nom du skieur: ");
          scanf("%s", nom);
          printf("\n");
        indice = indice_nom(nom, *taille_tableau, *tableau);
        if (indice == -1)
        {
            nouveau = 1;
            indice = *taille_tableau;
            ajouter_skieur(taille_tableau, tableau, nom);
        }
        do
        {
            printf("\t\t\t\t\t\tEntrez le nombre de reservations: ");
            scanf("%d", &nombre_reservations);
            printf("\n");
            if(nombre_reservations > TAILLE_RES)
            {
                printf("\t\t\t\t\t\tNombre maximum depasse!\n\n");
            }
            else if (nombre_reservations < 1)
            {
                printf("\t\t\t\t\t\tNombre incorrect!\n\n");
            }
        } while (nombre_reservations > TAILLE_RES);
        for (i=0 ; i<nombre_reservations ; i++)
        {
            printf("\t\t\t\t\t\t____________________Reservation :%2d____________________\n\n", i+1);
            do
            {
                printf("\t\t\t\t\t\tDonner la taille de la paire de ski souhaitee:");
                scanf("%d", &(res[i].taille));
                printf("\n");
                if (((res[i].taille) % 5 != 0) || ((res[i].taille) < 80) || ((res[i].taille) > 200)) printf("\t\t\t\t\t\tTaille indisponible!\n");
            } while (((res[i].taille) % 5 != 0) || ((res[i].taille) < 80) || ((res[i].taille) > 200));
            do
            {
                printf("\t\t\t\t\t\tDonner le jour de debut: ");
                scanf ("%d", &(res[i].debut));
                printf("\n");

                if (((res[i].debut) < 1) || ((res[i].debut) > 151)) printf("\t\t\t\t\t\tDate indisponible!\n");
            } while (((res[i].debut) < 1) || ((res[i].debut) > 151));
            do
            {
                printf("\t\t\t\t\t\tDonner le jour de fin:");
                scanf ("%d", &(res[i].fin));
                printf("\n");
                if (((res[i].fin) < (res[i].debut)) || ((res[i].fin) > 151)) {printf("\t\t\t\t\t\tDate indisponible!\n");
                    printf("\n");
                }
            } while (((res[i].fin) < (res[i].debut)) || ((res[i].fin) > 151));
            printf("\t\t\t\t\t\t\n");
        }
        for (i=0 ; i<nombre_reservations ; i++)
        {
            printf("\t\t\t\t\t\t____________________Reservation %2d____________________\n\n", i+1);
            reserver_tableau(liste, tableau, taille_tableau, res[i].debut, res[i].fin, res[i].taille, indice, nouveau);
            printf("\t\t\t\t\t\t______________________________________________________\n\n");
        }
        if ((*tableau)[indice].fois == 0) supprimer_dernier_skieur(taille_tableau, tableau);
        printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
    }

    // annuler toutes les reservations d'un skieur
    void annuler_reservations(liste_principale* liste, skieur* tableau, int* taille_tableau)
    {
        char nom[100];
        int indice;
            clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\t\e[34m ____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|                                            |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|            Anuuler Reservations            |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\n\n\n");
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
         printf("\t\t\t\t\t\tEntrer le nom du skieur: ");
        scanf("%s", nom);
printf("\n");

        indice = indice_nom(nom, *taille_tableau, tableau);
        if (indice == -1)
        {
            printf("\t\t\t\t\t\tRien a annuler ! \n\n");

        }
        else
        {
            supprimer_reservation(liste, tableau, taille_tableau, indice);
            printf("\t\t\t\t\t\tAnnule avec succes!\n");
        }
        printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
    }

//
void get_nom_highest_fois(skieur* tableau, int taille_tableau_skieur, int* max_fois, char** nom_max)
{
    //int max_fois = 0;
    //char* nom_max_fois = NULL;
    *nom_max = NULL;
    *max_fois = 0;
    for (int i = 0; i < taille_tableau_skieur; i++)
    {
        if (tableau[i].fois > *max_fois)
        {
            *max_fois = tableau[i].fois;
            *nom_max = tableau[i].nom;
        }
    }

    //return nom_max_fois;
}

//

// This function recursively traverses the list of main nodes and
// calculates the sum of (fin - deb + 1) for all nested nodes that
// have the specified taille value.
int sum_taille(liste_principale* p, int taille)
{
    int sum = 0;

    // Traverse the list of main nodes
    while (p != NULL)
    {
        // If the taille value of the current node matches the specified value
        if (p->taille_ski == taille)
        {
            // Traverse the list of nested nodes and calculate the sum of (fin - deb + 1)
            liste_locations* q = p->locations;
            while (q != NULL)
            {
                sum += q->fin - q->deb + 1;
                q = q->location_suivante;
            }
        }

        // Move to the next main node
        p = p->ski_suivant;
    }

    return sum;
}

int count_nodes(liste_principale* main_list) {
    int count = 0;
    liste_principale* current_node = main_list;
    while (current_node != NULL) {
        count++;
        current_node = current_node->ski_suivant;
    }
    return count;
}

//
int find_max_size(liste_principale* p)
{
    int max_size = 0;
    liste_locations* q = sous_liste(p);

    while (q != NULL)
    {
        int size = fin(q) - deb(q) + 1;
        if (size > max_size) {
            max_size = size;
        }
        q = location_suivante(q);
    }

    liste_principale* r = ski_suivant(p);
    while (r != NULL)
    {
        int size = find_max_size(r);
        if (size > max_size) {
            max_size = size;
        }
        r = ski_suivant(r);
    }

    return max_size;
}


// donne le nombre total de reservations
int total_reservations(liste_principale* p)
{
    int total = 0;
    while (p != NULL) {
        liste_locations* sousListe = sous_liste(p);
        while (sousListe != NULL) {
            total++;
            sousListe = location_suivante(sousListe);
        }
        p = ski_suivant(p);
    }
    return total;
}

// donne la duree moyenne d'une reservation
float average_duration(liste_principale* p) {
    int totalReservations = 0;
    int totalDuration = 0;
    while (p != NULL) {
        liste_locations* sousListe = sous_liste(p);
        while (sousListe != NULL) {
            totalReservations++;
            totalDuration += fin(sousListe) - deb(sousListe) + 1;
            sousListe = location_suivante(sousListe);
        }
        p = ski_suivant(p);
    }
    if (totalReservations == 0) {
        return 0;
    }
    return (float)totalDuration / totalReservations;
}


char* get_wilaya_name(int num)
{
    char* wilaya_name;
    switch(num) {
        case 1:
            wilaya_name = "Adrar";
            break;
        case 2:
            wilaya_name = "Chlef";
            break;
        case 3:
            wilaya_name = "Laghouat";
            break;
        case 4:
            wilaya_name = "Oum El Bouaghi";
            break;
        case 5:
            wilaya_name = "Batna";
            break;
        case 6:
            wilaya_name = "Bejaia";
            break;
        case 7:
            wilaya_name = "Biskra";
            break;
        case 8:
            wilaya_name = "Bechar";
            break;
        case 9:
            wilaya_name = "Blida";
            break;
        case 10:
            wilaya_name = "Bouira";
            break;
        case 11:
            wilaya_name = "Tamanrasset";
            break;
        case 12:
            wilaya_name = "Tebessa";
            break;
        case 13:
            wilaya_name = "Tlemcen";
            break;
        case 14:
            wilaya_name = "Tiaret";
            break;
        case 15:
            wilaya_name = "Tizi Ouzou";
            break;
        case 16:
            wilaya_name = "Alger";
            break;
        case 17:
            wilaya_name = "Djelfa";
            break;
        case 18:
            wilaya_name = "Jijel";
            break;
        case 19:
            wilaya_name = "Setif";
            break;
        case 20:
            wilaya_name = "Saida";
            break;
        case 21:
            wilaya_name = "Skikda";
            break;
        case 22:
            wilaya_name = "Sidi Bel Abbes";
            break;
        case 23:
            wilaya_name = "Annaba";
            break;
        case 24:
            wilaya_name = "Guelma";
            break;
        case 25:
            wilaya_name = "Constantine";
            break;
        case 26:
            wilaya_name = "Medea";
            break;
        case 27:
            wilaya_name = "Mostaganem";
            break;
        case 28:
            wilaya_name = "Msila";
            break;
        case 29:
            wilaya_name = "Mascara";
            break;
        case 30:
            wilaya_name = "Ouargla";
            break;
        case 31:
            wilaya_name = "Oran";
            break;
        case 32:
            wilaya_name = "El Bayadh";
            break;
        case 33:
            wilaya_name = "Illizi";
            break;
        case 34:
            wilaya_name = "El Bordj";
            break;
        case 35:
            wilaya_name = "Boumerdes";
            break;
        case 36:
            wilaya_name = "El Taref";
            break;
        case 37:
            wilaya_name = "Tindouf";
            break;
        case 38:
            wilaya_name = "Tissemsilt";
            break;
        case 39:
            wilaya_name = "El Oued";
            break;
        case 40:
            wilaya_name = "Khenchla";
            break;
        case 41:
            wilaya_name = "Souk-Ahras";
            break;
        case 42:
            wilaya_name = "Tipaza";
            break;
        case 43:
            wilaya_name = "Mila";
            break;
        case 44:
            wilaya_name = "Ain Defla";
            break;
        case 45:
            wilaya_name = "Naama";
            break;
        case 46:
            wilaya_name = "Ain Temouchent";
            break;
        case 47:
            wilaya_name = "Ghardaia";
            break;
        case 48:
            wilaya_name = "Relizane";
            break;
        case 49:
            wilaya_name = "Timimoun";
            break;
        case 50:
            wilaya_name = "Bourdj Badji Mokhtar";
            break;
        case 51:
            wilaya_name = "Ouled Djellal";
            break;
        case 52:
            wilaya_name = "Beni Abbes";
            break;
        case 53:
            wilaya_name = "Ain Salah";
            break;
        case 54:
            wilaya_name = "Ain Guezzam";
            break;
        case 55:
            wilaya_name = "Touggourt";
            break;
        case 56:
            wilaya_name = "Djanet";
            break;
        case 57:
            wilaya_name = "El-Mghayer";
            break;
        case 58:
            wilaya_name = "Meniaa";
            break;
        default:
            wilaya_name = "Invalide";
            break;
    }
    return wilaya_name;
}







