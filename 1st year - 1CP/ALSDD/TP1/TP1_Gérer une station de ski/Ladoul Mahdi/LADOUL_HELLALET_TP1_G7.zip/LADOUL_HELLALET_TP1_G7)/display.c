#include "display.h"
#include<unistd.h>

// efface l'ecran
void clrscr() {
    system("cls||clear");
}

// efface une line de l'ecran
void clrline() {
    printf("\e[2K");
    printf("\e[A");
}

// efface les menus de l'ecran
void clrmenu(int length) {
    for (int i = 0; i < length; i++) {
        gotoxy(55, 25+i);
        printf("                                                   ");
    }
}

void entete() {
    time_t t;
    t = time(NULL);
    struct tm tm = *localtime(&t);
    printf("\e[7;40m    Date: %02d/%02d/%04d                                    Ecole nationale Superieure d'Informatique (ALGER)                                          TP1 ALSDD    \e[0m", tm.tm_mday, tm.tm_mon+1, tm.tm_year+1900);
}

void pied()
{
    printf("\e[7;40m Ladoul Mahdi                                                    Station de ski GLISSE-GLACEE                                                   Hellalet Younes \e[0m");
}

// animation d'ecriture des chaines sur l'ecran ( typing-animation )
void strprintAnimate(char* str,int ms) {
    for (int i = 0; i < strlen(str); i++) {
        printf("%c", str[i]);
        usleep(ms*1000);
    }
}

// animation d'entr�e d'erreur
void inErrAnimate(char* str) {
    //printf(" ");
    clrline();
    for (int i = 1; i < 3; i++) {
        printf("\e[91m%s ", str);
        usleep(100000);
        printf("\r");
        printf("  %s", str);
        usleep(100000);
        printf("\r");
    }
    printf("\e[0m%s", str);
}

// un logo anim� personalis� de l'esi, pour le demarrage du programme
void esi_logo() {

    printf("\t\t\t\t\t    ");printf("\033[100m");printf("                 ");printf("\033[0m");printf("             ");printf("\033[100m");printf("                 ");printf("\033[0m");printf("           ");printf("\033[100m");printf("                   \n");
    printf("\033[0m");printf("\t\t\t\t\t  ");printf("\033[100m");printf("                     ");printf("\033[0m");printf("        ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[100m");printf("                     \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("          ");printf("\033[100m");printf("                 \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[100m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[100m");printf("          ");printf("\033[0m");printf("                          ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[100m");printf("          ");printf("\033[0m");printf("                           ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[100m");printf("          ");printf("\033[0m");printf("                           ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[100m");printf("           ");printf("\033[0m");printf("                          ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[100m");printf("                   ");printf("\033[0m");printf("                  ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("                       ");printf("\033[0m");printf("       ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("               ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("                       ");printf("\033[0m");printf("         ");printf("\033[100m");printf("                     ");printf("\033[0m");printf("              ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("                      ");printf("\033[0m");printf("            ");printf("\033[100m");printf("                   ");printf("\033[0m");printf("              ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("            ");printf("\033[0m");printf("                              ");printf("\033[100m");printf("           ");printf("\033[0m");printf("              ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("            ");printf("\033[0m");printf("                               ");printf("\033[100m");printf("          ");printf("\033[0m");printf("              ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[100m");printf("            ");printf("\033[0m");printf("                             ");printf("\033[100m");printf("           ");printf("\033[0m");printf("              ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("       ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("           ");printf("\033[100m");printf("                 \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t  ");printf("\033[100m");printf("                     ");printf("\033[0m");printf("       ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("         ");printf("\033[100m");printf("                     \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t    ");printf("\033[100m");printf("                 ");printf("\033[0m");printf("           ");printf("\033[100m");printf("                 ");printf("\033[0m");printf("             ");printf("\033[100m");printf("                   \n");usleep(50000);
    printf("\033[0m");



    gotoxy(0,3);
    printf("\t\t\t\t\t    ");printf("\033[104m");printf("                 ");printf("\033[0m");printf("             ");printf("\033[104m");printf("                 ");printf("\033[0m");printf("           ");printf("\033[107m");printf("                   \n");
    printf("\033[0m");printf("\t\t\t\t\t  ");printf("\033[104m");printf("                     ");printf("\033[0m");printf("        ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[107m");printf("                     \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("          ");printf("\033[107m");printf("                 \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[104m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[104m");printf("          ");printf("\033[0m");printf("                          ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[104m");printf("          ");printf("\033[0m");printf("                           ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[104m");printf("          ");printf("\033[0m");printf("                           ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[104m");printf("           ");printf("\033[0m");printf("                          ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[104m");printf("                   ");printf("\033[0m");printf("                  ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("                       ");printf("\033[0m");printf("       ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("               ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("                       ");printf("\033[0m");printf("         ");printf("\033[104m");printf("                     ");printf("\033[0m");printf("              ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("                      ");printf("\033[0m");printf("            ");printf("\033[104m");printf("                   ");printf("\033[0m");printf("              ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("            ");printf("\033[0m");printf("                              ");printf("\033[104m");printf("           ");printf("\033[0m");printf("              ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("            ");printf("\033[0m");printf("                               ");printf("\033[104m");printf("          ");printf("\033[0m");printf("              ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[104m");printf("            ");printf("\033[0m");printf("                             ");printf("\033[104m");printf("           ");printf("\033[0m");printf("              ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("       ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("           ");printf("\033[107m");printf("                 \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t  ");printf("\033[104m");printf("                     ");printf("\033[0m");printf("       ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("         ");printf("\033[107m");printf("                     \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t    ");printf("\033[104m");printf("                 ");printf("\033[0m");printf("           ");printf("\033[104m");printf("                 ");printf("\033[0m");printf("             ");printf("\033[107m");printf("                   \n");usleep(50000);
    printf("\033[0m");
}

// meme logo precedant, anim� en inverse, pour la fermeture du programme
void reverse_esi_logo(int y) {
    gotoxy(0, y);
    printf("\t\t\t\t\t    ");printf("\033[104m");printf("                 ");printf("\033[0m");printf("             ");printf("\033[104m");printf("                 ");printf("\033[0m");printf("           ");printf("\033[107m");printf("                   \n");
    printf("\033[0m");printf("\t\t\t\t\t  ");printf("\033[104m");printf("                     ");printf("\033[0m");printf("        ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[107m");printf("                     \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("          ");printf("\033[107m");printf("                 \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[104m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[104m");printf("          ");printf("\033[0m");printf("                          ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[104m");printf("          ");printf("\033[0m");printf("                           ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[104m");printf("          ");printf("\033[0m");printf("                           ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[104m");printf("           ");printf("\033[0m");printf("                          ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[104m");printf("                   ");printf("\033[0m");printf("                  ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("                       ");printf("\033[0m");printf("       ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("               ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("                       ");printf("\033[0m");printf("         ");printf("\033[104m");printf("                     ");printf("\033[0m");printf("              ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("                      ");printf("\033[0m");printf("            ");printf("\033[104m");printf("                   ");printf("\033[0m");printf("              ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("            ");printf("\033[0m");printf("                              ");printf("\033[104m");printf("           ");printf("\033[0m");printf("              ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[104m");printf("            ");printf("\033[0m");printf("                               ");printf("\033[104m");printf("          ");printf("\033[0m");printf("              ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[104m");printf("            ");printf("\033[0m");printf("                             ");printf("\033[104m");printf("           ");printf("\033[0m");printf("              ");printf("\033[107m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("       ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("           ");printf("\033[107m");printf("                 \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t  ");printf("\033[104m");printf("                     ");printf("\033[0m");printf("       ");printf("\033[104m");printf("                      ");printf("\033[0m");printf("         ");printf("\033[107m");printf("                     \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t    ");printf("\033[104m");printf("                 ");printf("\033[0m");printf("           ");printf("\033[104m");printf("                 ");printf("\033[0m");printf("             ");printf("\033[107m");printf("                   \n");usleep(50000);
    printf("\033[0m");

    gotoxy(0, y);
    printf("\t\t\t\t\t    ");printf("\033[100m");printf("                 ");printf("\033[0m");printf("             ");printf("\033[100m");printf("                 ");printf("\033[0m");printf("           ");printf("\033[100m");printf("                   \n");
    printf("\033[0m");printf("\t\t\t\t\t  ");printf("\033[100m");printf("                     ");printf("\033[0m");printf("        ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[100m");printf("                     \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("          ");printf("\033[100m");printf("                 \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[100m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[100m");printf("          ");printf("\033[0m");printf("                          ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[100m");printf("          ");printf("\033[0m");printf("                           ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[100m");printf("          ");printf("\033[0m");printf("                           ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("            ");printf("\033[0m");printf("                  ");printf("\033[100m");printf("           ");printf("\033[0m");printf("                          ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("                      ");printf("\033[0m");printf("        ");printf("\033[100m");printf("                   ");printf("\033[0m");printf("                  ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("                       ");printf("\033[0m");printf("       ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("               ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("                       ");printf("\033[0m");printf("         ");printf("\033[100m");printf("                     ");printf("\033[0m");printf("              ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("                      ");printf("\033[0m");printf("            ");printf("\033[100m");printf("                   ");printf("\033[0m");printf("              ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("            ");printf("\033[0m");printf("                              ");printf("\033[100m");printf("           ");printf("\033[0m");printf("              ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t");printf("\033[100m");printf("            ");printf("\033[0m");printf("                               ");printf("\033[100m");printf("          ");printf("\033[0m");printf("              ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[100m");printf("            ");printf("\033[0m");printf("                             ");printf("\033[100m");printf("           ");printf("\033[0m");printf("              ");printf("\033[100m");printf("        \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("       ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("           ");printf("\033[100m");printf("                 \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t  ");printf("\033[100m");printf("                     ");printf("\033[0m");printf("       ");printf("\033[100m");printf("                      ");printf("\033[0m");printf("         ");printf("\033[100m");printf("                     \n");usleep(50000);
    printf("\033[0m");printf("\t\t\t\t\t    ");printf("\033[100m");printf("                 ");printf("\033[0m");printf("           ");printf("\033[100m");printf("                 ");printf("\033[0m");printf("             ");printf("\033[100m");printf("                   \n");usleep(50000);
    printf("\033[0m");

    for (int i = 0; i < 17; i++) {
        gotoxy(0, y+i);
        printf("                                                                                                                                                                 ");
        usleep(60000);
    }

}

void titre_logo() {
    printf("\n");
printf("\n");
printf("\n");
    printf("_______________________________________________________________________________________________________________________________________________________________\n");
    printf("_______________________________________________________________________________________________________________________________________________________________\n");
    printf(" ");
printf("\n ");
printf("\n ");

printf("\033[1;34m"); // set text color to cyan
printf("                            ______   _____ _________ ____  _____ ____   ____ _________ ____  _____ _____  _____ _________ \n");
printf("                            |_   _ \\ |_   _|_   ___  |_   \\|_   _|_  _| |_  _|_   ___  |_   \\|_   _|_   _||_   _|_   ___  |\n");
printf("                              | |_) |  | |   | |_  \\_| |   \\ | |   \\ \\   / /   | |_  \\_| |   \\ | |   | |    | |   | |_  \\_|\n");
printf("                              |  __/.  | |   |  _|  _  | |\\ \\| |    \\ \\ / /    |  _|  _  | |\\ \\| |   | '    ' |   |  _|  _ \n");
printf("                             _| |__)| _| |_ _| |___/ |_| |_\\   |_    \\ ' /    _| |___/ |_| |_\\   |_   \\ \\--' /   _| |___/ |\n");
printf("                            |_______/|_____|_________|_____|\\____|    \\_/    |_________|_____|\\____|   \\.__.'   |_________|\n");
    printf("\033[0m"); // reset text color

printf("\n");
printf("\n");


    printf("_______________________________________________________________________________________________________________________________________________________________\n");
        printf("_______________________________________________________________________________________________________________________________________________________________\n");

}

// animation du texte clignotant sur l'ecran
void strprintblink (char* word, int blink_number, int blink_rate) {
    while( (blink_number != 1 )){
        usleep(blink_rate*10000);
        printf("\r");
        printf("\033[1;90m");
        printf("%s",word);

        usleep(100000);
        printf("\r");
        printf("\033[0m");

        printf("%s",word);

        usleep(100000);
        printf("\r");
        printf("\033[1;37m");

        printf("%s",word);

        usleep(blink_rate*10000/2);
        printf("\r");
        printf("\033[0m");

        printf("%s",word);

        usleep(100000);
        printf("\r");
        printf("\033[1;90m");

        printf("%s",word);

        usleep(100000);
        printf("\r");
        for (int i = 1 ; i <= strlen(word); i++) {
            printf(" ");
        }
        blink_number = blink_number - 1 ;
    }
    printf("\033[0m");

}

// meme animation pr�c�dante + l'option de l'arreter suite a une frappe du clavier (keyboard hit)
void strprintblinkkbhit(char* word, int blink_number, int blink_rate) {

    while((!kbhit()) && (blink_number != 1 )){
        usleep(blink_rate*5000);
        printf("\r");
        printf("\033[1;90m");
        printf("%s",word);
        if (kbhit()) {break;}
        usleep(100000);
        printf("\r");
        printf("\033[0m");

        printf("%s",word);
        if (kbhit()) {break;}
        usleep(100000);
        printf("\r");
        printf("\033[1;37m");

        printf("%s",word);
        if (kbhit()) {break;}
        usleep(blink_rate*10000/2);
        printf("\r");
        printf("\033[0m");

        printf("%s",word);
        if (kbhit()) {break;}
        usleep(100000);
        printf("\r");
        printf("\033[1;90m");

        printf("%s",word);
        if (kbhit()) {break;}
        usleep(100000);
        printf("\r");
        for (int i = 1 ; i <= strlen(word); i++) {
            printf(" ");
        }
        blink_number = blink_number - 1 ;
    }
    printf("\033[0m");
}

// page d'introduction du projet
void intro() {
    printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    strprintblinkkbhit("                                                          Ladoul Mahdi & Hellalet Younes presentent                                              ",2,500);
    strprintblinkkbhit("                                                         Sous la supervision du Professeur Kermi Adel                                            ",2,500);
    //sleep(2);
    Sleep (2);
}

// fonction tres utilis�e pour deplacer le curseur sur l'ecran
void gotoxy(SHORT x1, SHORT y1) {
    COORD c;
    c.X = x1;
    c.Y = y1;

    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), c);
}

// animation du texte (fade-in)
void fade_in(char* word , int speed_ms, char* space) {
    usleep(speed_ms*1000);
    printf("\r");
    printf("%s", space);
    printf("\033[1;90m");
    printf("%s",word);
    printf("\t\t\t\t\t\t\t");

    usleep(100000);
    printf("\r");
    printf("%s", space);
    printf("\033[0m");

    printf("%s",word);
    printf("\t\t\t\t\t\t\t");

    usleep(100000);
    printf("\r");
    printf("%s", space);
    printf("\033[1;37m");

    printf("%s",word);
    printf("\t\t\t\t\t\t\t");

    usleep(speed_ms*1000/2);
    printf("\r");
    printf("%s", space);
    printf("\033[0m");

    printf("%s",word);
    printf("\t\t\t\t\t\t\t");
}

// animation du text (fade-out)
void fade_out(char* word, int speed_ms) {
        printf("\e[0m");

        printf("%s",word);

        usleep(200000);
        printf("\r");
        printf("\e[1;90m");

        printf("%s",word);

        usleep(1000*speed_ms);
        printf("\r");
        for (int i = 1 ; i <= strlen(word); i++) {
            printf(" ");
        }
        printf("\e[0m");
}
