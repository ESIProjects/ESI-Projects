#include "menus.h"
#include "header.h"
#include "display.h"
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include <unistd.h>



/*---------- fonction_de_base ----------*/

// fonction qui affiche les menus de selection
void selectionner(char* str_array[], int tai, int x, int* y) {
    int initial_y = *y ;
    *y = 0;
    printf("\n");
    for (int i = 0; i < tai; i++) {                           // affichage du menu
        gotoxy(x, (*y)+initial_y+i);
        fade_in(str_array[i], 1, "\t\t\t\t\t\t       ");
        usleep(1000);
    }
    printf("\n\t\t\t\t\t\t       ___________________________________________________");

    printf("\n\n");
    strprintblink("\t\t\t\t\t\t\t            <SELECTIONNER UNE ENTREE>",2,100);
    clrline();
    printf("\n\n\n");

    gotoxy(x,(*y)+initial_y);
    printf("\e[107m");
    printf("\e[30m");
    printf("%s",str_array[0]);
    printf("\033[0m");
    gotoxy(x,(*y)+initial_y);

    time_t t_origine = time(NULL);

    char command = getch();                                   // une variable qui contient la derniere touche du clavier frapp�e par l'utilisateur
    while (command == 13 && (time(NULL)-t_origine)<0.5) {
        command = getch();
    }

    while(1)                                                  // 13 pour <ENTRER> , 72 pour <HAUT> , 80 pour <BAS>
    {

        if ( command == 72) {
            *y = ((*y) + tai-1 )%tai ;

            printf("%s",str_array[((*y)+1) % tai]);

            gotoxy(x,(*y)+initial_y);
            printf("\e[107m");
            printf("\e[30m");
            printf("%s",str_array[(*y)]);
            printf("\033[0m");
            gotoxy(x,(*y)+initial_y);
        }

        else if (command == 80) {
            *y = ((*y) +1 )%tai;
            printf("%s",str_array[((*y)+(tai-1)) % tai]);
            gotoxy(x,(*y)+initial_y);
            printf("\e[107m");
            printf("\e[30m");
            printf("%s",str_array[(*y)]);
            printf("\033[0m");
            gotoxy(x,(*y)+initial_y);
        }
        else if ( command == 13){
            break ;
        }
        command = getch();
    }
}


/*--------- page_de_chargement ---------*/

// page de chargement (+ animation de chargement)
void loading_page() {
    srand(time(NULL));
    int nombre = rand()%7;                                    // nombre aleatoire entre 0 et 5 pour choisir une astuce aleatoire (ci-dessous)
    char* astuce[10] =  {"                                         Ne vous fatiguez pas a regler la taille de la fenetre, on l'a fait pour vous !",
                         "                                             Sur une echelle de 0 a 10, combien notez-vous cet ecran de chargement ?",
                         "                         Vous pouvez utiliser l'option <Quitter l'application> au lieu du X en haut de la fenetre, c'est plus securisee!",
                         "                                                            Ce TP n'est pas pour les ames sensibles !",
                         "                                        Vous pouvez sauter l'introduction du programme en appuyant sur la touche <entrer>",
                         "                                  Saviez vous que notre bibliotheque graphique est constituee de 95% de procedures faites maison !",
                         "                    Ne soyez pas timide, vous pouvez demander a notre moteur de recherche - jury - tous ce que vous voulez !( presque tout )"};


    clrscr();                                                 // mise en page
    printf("\n\n\n");
    esi_logo();
    printf("\n\n\n\n\n\n");
    sleep(1);
    for ( int j = 0 ; j <= 100 ; j++) {

        printf("                                                                       Chargement");
        for (int i =1 ; i <= j % 15 ; i=i+5) {                // affichage : "Chargement.", "Chargement..",  "Chargement...", ...
            printf(".");
        }
        for (int i =0 ; i <= 15 - j % 15; i=i+5) {
            printf(" ");
        }

        printf("  %d%%  ",j);
        printf("\n\n");
        printf("                             ____________________________________________________________________________________________________");
        printf("\n                             ");
        printf("\033[107m");
        printf("\033[97m");

        for (int k = 1 ; k <= j ; k++){                       // barre de chargement
            printf("#");
        }
         printf("\033[0m");

        for (int f = 1 ; f <= 100 - j ; f ++) {
            printf("_");
        }
        printf("|");

        printf("\n\n\n\n\n\n");
        printf("\e[93m");
        printf("%s\n",astuce[nombre]);
        printf("\033[0m");

        //usleep(50000);
        usleep(5000);
        clrline();
        clrline();
        clrline();
        clrline();
        clrline();
        clrline();
        clrline();
        clrline();
        clrline();
        clrline();
        printf("\033[0m");


    }
    clrline();
    clrline();
    clrline();
    clrline();
    printf("\033[0m");
    printf("\033[93m");
    printf("\n\n\n\n                                                                            TERMIN%c!                                                     ", 144);
    printf("\e[0m");
    sleep(1);
}

/*----------- menu_principal -----------*/

void menu(salles classee) {
        // initialiser la fonction random
    srand(time(NULL));
    // declarations
    liste_principale* tete_liste_principale; //  declarer la liste principale
    skieur* tableau_skieur = NULL; // declarer le tableau
    int nombre_skieurs = random(MIN_SKIEURS, MAX_SKIEURS);
    int nombre_skis = random(MIN_SKIS, MAX_SKIS);
    // programme
    creer_structure(&tete_liste_principale, &tableau_skieur, &nombre_skieurs, &nombre_skis);
    bool quit = false;
    char* menu_list [9] = { "          1. Afficher La Liste                     ",
                            "          2. Reserver plusieurs paires             ",
                            "          3. Statistiques                          ",
                            "          4. Reserver une paire                    ",
                            "          5. Annuler toutes les reservations       ",
                            "          6. Quitter                                ",
                            };

    do {
        clrscr();                                             // mise en page
        entete();
        printf("\n\n\n");
        titre_logo();
        gotoxy(0, NB_LINES-1);
        pied();
        gotoxy(0, 18);
        strprintAnimate("\n\n\n\n\t\t\t\t\t\t\t\t\t \e[1;93mMENU PRINCIPAL",40);
        printf("\e[0m");
        printf("\n\t\t\t\t\t\t       ___________________________________________________\n");


        int y = 25 ;
        selectionner(menu_list,6, 55, &y);
        switch (y) {
       case 0:
            clrscr();                                             // mise en page
            afficher_liste(tete_liste_principale);
            printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr();
           break;
            case 1:
            clrscr();
            reserver_plusieurs(tete_liste_principale, &tableau_skieur, &nombre_skieurs);
            printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr();
            break;
        case 2:

                    clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\033[1;36m"); // Set text color to cyan
            printf("\t\t\t\t\t\t       _______ _______ _______ _______ _______ \n");
            printf("\t\t\t\t\t\t      |  _____|_     _|   _   |_     _|  _____|\n");
            printf("\t\t\t\t\t\t      | |_____  |   | |  |_|  | |   | | |_____ \n");
            printf("\t\t\t\t\t\t      |_____  | |   | |       | |   | |_____  |\n");
            printf("\t\t\t\t\t\t       _____| | |   | |   _   | |   |  _____| |\n");
            printf("\t\t\t\t\t\t      |_______| |___| |__| |__| |___| |_______|\n\n");
            printf("\033[0m"); // Reset text color
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("\n");
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\t 1. Afficher Le tableau \n\n");//<
            printf("\t\t\t\t\t\t\t 2. Client(e) le/la plus fidele  \n\n");//<
            printf("\t\t\t\t\t\t\t 3. Le Nombre de jours d'allocation d'une taille  \n\n");//
            printf("\t\t\t\t\t\t\t 4. Le Nombre des  paires de ski existantes \n\n");//
            printf("\t\t\t\t\t\t\t 5. Le Nombre de clients \n\n");//<
            printf("\t\t\t\t\t\t\t 6. Le Nombre des reservations \n\n");//<
            printf("\t\t\t\t\t\t\t 7. Duree moyenne d'une reservation \n\n");//<
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            int choix = 0 ;
            while ( choix < 1 || choix > 7) {
            printf("\t\t\t\t\t\t\tChoix ? : ");
            scanf("%d",&choix);
            printf("\n");
            if ( choix < 1 || choix > 7 ) {
            printf("\t\t\t\t\t\tOption inexistante ! \n\n");
            };
            };

            switch (choix){

        case 1:
            clrscr();                                             // mise en page
            afficher_tableau(tableau_skieur, nombre_skieurs);
            printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr();
            break;
        case 2:
            clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\t\e[34m ____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|                                            |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|        Le client le plus fidele            |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            char* dude;
            int max_fois;
            get_nom_highest_fois(tableau_skieur,nombre_skieurs, &max_fois, &dude);
            //char* dude = get_nom_highest_fois(tableau_skieur,nombre_skieurs);
            printf("\n\n\n");
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\tLe/La client(e) le/la plus fidele est : %s\n\n",dude);
            printf("\t\t\t\t\t\tavec %d reservations\n", max_fois);
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr();
            break;

            case 3:
            clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\t\e[34m _____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|                                             |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|Le nombre des jours d'allocation d'une taille|\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|_____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\n\n\n\n\n\n");
            int t ;
            printf("\t\t\t\t\t\tDonnez La taille de ski :");
            scanf("%d",&t);
            printf("\n");
            int sum = sum_taille(tete_liste_principale ,t);
            printf("\t\t\t\t\t\tLe Nombre Des Jours D'allocation des Skis de cette taille est : %d\n\n",sum);
            printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr();
            break;

            case 4:
            clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\t\e[34m _____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|                                             |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|             Le nombre des paires              |\e[0m\n");
            printf("\t\t\t\t\t\t\t\e[34m|_____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\n\n\n\n\n\n");
            int mahdi = count_nodes(tete_liste_principale);
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\tLe nombre des paires est : %d\n\n", mahdi);
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr();
            break;

            case 5:
            clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\e[34m ____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\e[34m|                                            |\e[0m\n");
            printf("\t\t\t\t\t\t\e[34m|           Le Nombre de Clients            |\e[0m\n");
            printf("\t\t\t\t\t\t\e[34m|____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\n\n\n\n\n\n");
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\tLe Nombre de clients est : %d\n\n",nombre_skieurs);
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr();
            break;
              case 6:
            clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\e[34m ____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\e[34m|                                            |\e[0m\n");
            printf("\t\t\t\t\t\t\e[34m|             Total Reservations             |\e[0m\n");
            printf("\t\t\t\t\t\t\e[34m|____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\n\n\n");

            int total = total_reservations(tete_liste_principale);
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\tNombre total de reservations :%d\n\n",total);
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr();
            break;
            case 7:
            clrscr();
            printf("\n\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\t\e[34m ____________________________________________\e[0m\n");
            printf("\t\t\t\t\t\t\e[34m|                                            |\e[0m\n");
            printf("\t\t\t\t\t\t\e[34m|        Duree moyenne de reservation        |\e[0m\n");
            printf("\t\t\t\t\t\t\e[34m|____________________________________________|\e[0m\n\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n");
            printf("_______________________________________________________________________________________________________________________________________________________________\n\n");
            printf("\n\n\n");

            float average = average_duration(tete_liste_principale);
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\tLa duree moyenne est %f jours\n\n", average);
            printf("\t\t\t\t\t\t____________________________________________________________________________\n\n");
            printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr();
            break;
            };
            break;
        case 3:
            clrscr();
            reserver(tete_liste_principale, &tableau_skieur, &nombre_skieurs);
            printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr()          ;                   // mise en page
            break;
       case 4:
            clrscr();
            annuler_reservations(tete_liste_principale, tableau_skieur, &nombre_skieurs);
            printf("\t\t\t\t\t\tAppuyez sur <entrer> pour continuer\n\n");
            getch();
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tChargement... ",2,500);
            clrscr();
         break;
        case 5:
            // mise en page
            quit = 1 ;
            clrscr();
            printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
            strprintblinkkbhit("\t\t\t\t\t\t\t\t\tTermine !",2,500);
            clrscr();
            break;
        }
    } while (!quit);
    getchar();
}

