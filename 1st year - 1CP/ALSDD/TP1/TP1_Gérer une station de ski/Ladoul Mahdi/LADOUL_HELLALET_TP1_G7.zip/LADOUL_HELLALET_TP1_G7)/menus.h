#ifndef MENUS_H_INCLUDED
#define MENUS_H_INCLUDED

#include "header.h"
#include "display.h"

void selectionner(char* str_array[], int tai, int x, int* y);

void loading_page();

void menu(salles classee);

void chargement(salles CP, char* fname);

void affichage(salles CP, ptr_soutenance listeSIQ, ptr_soutenance listeSIL, ptr_soutenance listeSIT);

void quitter(salles classe,ptr_soutenance* SIQ,ptr_soutenance* SIL, ptr_soutenance* SIT);

#endif // MENUS_H_INCLUDED
