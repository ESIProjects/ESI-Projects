  /**--------------------------------------------------------**/
  /**       T r a n s l a t i o n   Z to C (Standard)        **/
  /**             By Pr. D.E ZEGOUR                          **/
  /**             E S I - Algier                             **/
  /**             Copywrite 2014                             **/
  /**--------------------------------------------------------**/

  #include <stdio.h>
  #include <stdlib.h>
  #include <Time.h>

  typedef int bool ;

  #define True 1
  #define False 0

  /** -Implementation- **\: BINARY SERACH TREE OF INTEGERS**/

  /** Binary search trees **/

  typedef int Typeelem_Ai   ;
  typedef struct Noeud_Ai * Pointer_Ai ;

  struct Noeud_Ai
    {
      Typeelem_Ai  Val ;
      Pointer_Ai Fg ;
      Pointer_Ai Fd ;
      Pointer_Ai Pere ;
     } ;

  Typeelem_Ai Node_value_Ai( Pointer_Ai P )
    { return P->Val;   }

  Pointer_Ai Lc_Ai( Pointer_Ai P)
    { return P->Fg ; }

  Pointer_Ai Rc_Ai( Pointer_Ai P)
    { return P->Fd ; }

  Pointer_Ai Parent_Ai( Pointer_Ai P)
    { return P->Pere ; }

  void Ass_node_val_Ai ( Pointer_Ai P, Typeelem_Ai Val)
    {
       P->Val = Val ;
    }

  void Ass_lc_Ai( Pointer_Ai P, Pointer_Ai Q)
    { P->Fg =  Q;  }

  void Ass_rc_Ai( Pointer_Ai P, Pointer_Ai Q)
    { P->Fd =  Q ; }

  void Ass_parent_Ai( Pointer_Ai P, Pointer_Ai Q)
    { P->Pere =  Q ; }

  void Allocate_node_Ai( Pointer_Ai *P)
    {
      *P = (struct Noeud_Ai *) malloc( sizeof( struct Noeud_Ai))   ;
      (*P)->Fg = NULL;
      (*P)->Fd = NULL;
      (*P)->Pere = NULL;
    }

  void Free_node_Ai( Pointer_Ai P)
    { free( P ) ; }


  /** -Implementation- **\: ARRAY OF INTEGERS**/

  /** Arrays **/

  typedef int Typeelem_V100i ;
  typedef Typeelem_V100i * Typevect_V100i ;

  Typeelem_V100i Element_V100i ( Typevect_V100i V , int I1  )
    {
      return  *(V +  (I1-1)  ) ;
    }

  void Ass_element_V100i ( Typevect_V100i V  , int I1 ,  Typeelem_V100i Val )
    {
      *(V +  (I1-1)  ) = Val ;
    }


  /** -Implementation- **\: STACK OF BINARY SERACH TREES OF INTEGERS**/
  /** Stacks**/

  typedef Pointer_Ai Typeelem_PAi ;
  typedef struct Maillon_PAi * Pointer_PAi ;
  typedef   Pointer_PAi  Typepile_PAi  ;

  struct Maillon_PAi
    {
      Typeelem_PAi  Val ;
      Pointer_PAi Suiv ;
    } ;

  void Createstack_PAi( Pointer_PAi *P )
    { *P = NULL ; }

  bool Empty_stack_PAi ( Pointer_PAi P )
    { return  (P == NULL ); }

  void Push_PAi ( Pointer_PAi *P,  Typeelem_PAi Val )
    {
      Pointer_PAi Q;

      Q = (struct Maillon_PAi *) malloc( sizeof( struct Maillon_PAi))   ;
      Q->Val = Val ;
      Q->Suiv = *P;
      *P = Q;
    }

  void Pop_PAi ( Pointer_PAi *P,  Typeelem_PAi *Val )
    {
      Pointer_PAi Sauv;

      if (! Empty_stack_PAi (*P) )
        {
          *Val = (*P)->Val ;
          Sauv = *P;
          *P = (*P)->Suiv;
          free(Sauv);
        }
      else printf ("%s \n", "Stack is empty");
    }


  /** -Implementation- **\: QUEUE OF BINARY SERACH TREES OF INTEGERS**/
  /** Queues **/

  typedef Pointer_Ai Typeelem_FAi ;
  typedef  struct Filedattente_FAi * Pointer_FAi ;
  typedef  struct Maillon_FAi * Ptliste_FAi ;

  struct Maillon_FAi
    {
      Typeelem_FAi Val ;
      Ptliste_FAi Suiv  ;
    };

  struct Filedattente_FAi
    {
      Ptliste_FAi Tete, Queue ;
    };

  void Createqueue_FAi ( Pointer_FAi *Fil   )
    {
      *Fil = (struct Filedattente_FAi *) malloc( sizeof( struct Filedattente_FAi)) ;
      (*Fil)->Tete = NULL ;
      (*Fil)->Queue = NULL ;
    }

  bool Empty_queue_FAi (Pointer_FAi Fil  )
    { return  Fil->Tete == NULL ;}

  void Enqueue_FAi ( Pointer_FAi Fil , Typeelem_FAi Val   )
    {
      Ptliste_FAi Q;

      Q = (struct Maillon_FAi *) malloc( sizeof( struct Maillon_FAi))   ;
      Q->Val = Val ;
      Q->Suiv = NULL;
      if ( ! Empty_queue_FAi(Fil) )
        Fil->Queue->Suiv = Q ;
      else Fil->Tete = Q;
        Fil->Queue = Q;
    }

  void Dequeue_FAi (Pointer_FAi Fil, Typeelem_FAi *Val )
    {
      if (! Empty_queue_FAi(Fil) )
        {
          *Val = Fil->Tete->Val ;
          Fil->Tete =  Fil->Tete->Suiv;
        }
      else printf ("%s \n", "Queue is empty");
    }


  /** Variables of main program **/
  Pointer_Ai A1=NULL;
  Pointer_Ai A2=NULL;
  Pointer_Ai A3=NULL;
  int Nb;
  int I;
  int C;
  int N;
  int M;
  Typevect_V100i T;

  /** Standard functions **/

  int Max (int a, int b)
    {
      if (a > b) return(a);
      else return(b);
    }

  int Min (int a, int b)
    {
      if (a < b) return(a);
      else return(b);
    }

  int Aleanombre( int N )
    { return ( rand() % N ); }


 /** Function prototypes **/

  void Bst_insert_sans_dup (Pointer_Ai *P , int *V);
  void Bst_insert (Pointer_Ai *P , int *V);
  void Next_preordre (Pointer_Ai *P , Pointer_PAi *Pil);
  void Next_inordre (Pointer_Ai *P , bool *T , Pointer_PAi *Pil);
  void Next_postordre (Pointer_Ai *P , Pointer_Ai *Sauv , bool *Test , Pointer_PAi *Pil);
  void Preordre_preordre (Pointer_Ai *P , Pointer_Ai *Q , Pointer_Ai *Arb3);
  void Inordre_preordre (Pointer_Ai *P , Pointer_Ai *Q , Pointer_Ai *Arb3);
  void Postordre_postordre (Pointer_Ai *P , Pointer_Ai *Q , Pointer_Ai *Arb3);
  void Inordre_postordre (Pointer_Ai *P , Pointer_Ai *Q , Pointer_Ai *Arb3);
  void Preordre_postordre (Pointer_Ai *P , Pointer_Ai *Q , Pointer_Ai *Arb3);
  int Noeud_par_niv_max (Pointer_Ai *P);
  int  Hauteur_max (Pointer_Ai *P) ;
  int  Hauteur_min (Pointer_Ai *P) ;
  int  Balance (Pointer_Ai *P) ;
  void Generation_de_arbre (Pointer_Ai *A , int *N);

  /*--------procedure qui inserer une valeur dans un ARB sans les doubles--------*/
  void Bst_insert_sans_dup (Pointer_Ai *P , int *V)
    {
      /** Local variables **/
      Pointer_Ai Pp=NULL;
      Pointer_Ai Q=NULL;
      bool Test;

      /** Body of function **/
     Pp  =  *P ;
     Test  =  False ;
     while( Test == False)  {
       if( ( *V < Node_value_Ai ( Pp ) ) && ( Lc_Ai ( Pp ) == NULL ))   {
         Allocate_node_Ai (& Q ) ;
         Ass_node_val_Ai ( Q , *V ) ;
         Ass_lc_Ai ( Pp , Q ) ;
         Test  =  True ;
         }
       else
         {
         if( ( *V > Node_value_Ai ( Pp ) ) && ( Rc_Ai ( Pp ) == NULL ))   {
           Allocate_node_Ai (& Q ) ;
           Ass_node_val_Ai ( Q , *V ) ;
           Ass_rc_Ai ( Pp , Q ) ;
           Test  =  True ;
           }
         else
           {
           if( *V < Node_value_Ai ( Pp ))   {
             Pp  =  Lc_Ai ( Pp ) ;
             }
           else
             {
             if( *V > Node_value_Ai ( Pp ))   {
               Pp  =  Rc_Ai ( Pp ) ;
               }
             else
               {
               Test  =  True ;

             }
           }
         }
       }
     }
    }
  /*--------procedure qui inserer une valeur dans un ARB avec les doubles--------*/
  void Bst_insert (Pointer_Ai *P , int *V)
    {
      /** Local variables **/
      Pointer_Ai Pp=NULL;
      Pointer_Ai Q=NULL;
      bool Test;

      /** Body of function **/
     Pp  =  *P ;
     Test  =  False ;
     while( Test == False)  {
       if( ( *V <= Node_value_Ai ( Pp ) ) && ( Lc_Ai ( Pp ) == NULL ))   {
         Allocate_node_Ai (& Q ) ;
         Ass_node_val_Ai ( Q , *V ) ;
         Ass_lc_Ai ( Pp , Q ) ;
         Test  =  True ;
         }
       else
         {
         if( ( *V > Node_value_Ai ( Pp ) ) && ( Rc_Ai ( Pp ) == NULL ))   {
           Allocate_node_Ai (& Q ) ;
           Ass_node_val_Ai ( Q , *V ) ;
           Ass_rc_Ai ( Pp , Q ) ;
           Test  =  True ;
           }
         else
           {
           if( *V <= Node_value_Ai ( Pp ))   {
             Pp  =  Lc_Ai ( Pp ) ;
             }
           else
             {
             if( *V > Node_value_Ai ( Pp ))   {
               Pp  =  Rc_Ai ( Pp ) ;
               }
             else
               {
               Test  =  True ;

             }
           }
         }
       }
     }
    }
  /*---------procedure qui modifier le noeud P par son suivant preordre-------------*/
  void Next_preordre (Pointer_Ai *P , Pointer_PAi *Pil)
    {
      /** Local variables **/
      Pointer_Ai T=NULL;

      /** Body of function **/
     if( Lc_Ai ( *P ) != NULL)   {
       T  =  *P ;
       Push_PAi (& *Pil , T ) ;
       *P  =  Lc_Ai ( *P ) ;
       }
     else
       {
       if( Rc_Ai ( *P ) != NULL)   {
         *P  =  Rc_Ai ( *P ) ;
         }
       else
         {
         while( ( Rc_Ai ( *P ) == NULL ) && ( Empty_stack_PAi ( *Pil ) == False ))  {
           Pop_PAi (& *Pil , &*P ) ;

         } ;
         *P  =  Rc_Ai ( *P ) ;

       } ;

     }
    }
  /*---------procedure qui modifier le noeud P par son suivant inordre-------------*/
  void Next_inordre (Pointer_Ai *P , bool *T , Pointer_PAi *Pil)
    {
      /** Local variables **/
      Pointer_Ai K=NULL;

      /** Body of function **/
     if( ( Lc_Ai ( *P ) != NULL ) && ( *T == False ))   {
       while( ( *P != NULL ))  {
         K  =  *P ;
         Push_PAi (& *Pil , K ) ;
         *P  =  Lc_Ai ( *P ) ;

       } ;
       if( Empty_stack_PAi ( *Pil ) == False)   {
         Pop_PAi (& *Pil , &*P ) ;

       } ;
       }
     else
       {
       if( Rc_Ai ( *P ) != NULL)   {
         *P  =  Rc_Ai ( *P ) ;
         *T  =  False ;
         while( ( Lc_Ai ( *P ) != NULL ))  {
           K  =  *P ;
           Push_PAi (& *Pil , K ) ;
           *P  =  Lc_Ai ( *P ) ;

         } ;
         }
       else
         {
         if( Empty_stack_PAi ( *Pil ) == False)   {
           Pop_PAi (& *Pil , &*P ) ;
           *T  =  True ;
           }
         else
           {
           *P  =  NULL ;

         } ;

       } ;

     } ;

    }
  /*---------procedure qui modifier le noeud P par son suivant postordre-------------*/
  void Next_postordre (Pointer_Ai *P , Pointer_Ai *Sauv , bool *Test , Pointer_PAi *Pil)
    {
      /** Local variables **/
      Pointer_Ai K=NULL;
      bool Trouve;

      /** Body of function **/
     Trouve  =  False ;
     while( ( Empty_stack_PAi ( *Pil ) == False ) && ( Trouve == False ))  {
       while( ( *P != NULL ) && ( *Test == False ))  {
         K  =  *P ;
         Push_PAi (& *Pil , K ) ;
         *P  =  Lc_Ai ( *P ) ;

       } ;
       Pop_PAi (& *Pil , &*P ) ;
       *Test  =  True ;
       if( ( Rc_Ai ( *P ) == NULL ) || ( *Sauv == Rc_Ai ( *P ) ))   {
         Trouve  =  True ;
         *Sauv  =  *P ;
         }
       else
         {
         K  =  *P ;
         Push_PAi (& *Pil , K ) ;
         *Sauv  =  *P ;
         *P  =  Rc_Ai ( *P ) ;
         *Test  =  False ;

       } ;

     } ;
     if( ( Trouve == False ) && ( Empty_stack_PAi ( *Pil ) == True ))   {
       *P  =  NULL ;

     } ;

    }
  /*-procedure qui fusion deux arb p et q selon preordre pour p ,et preordre pour q dans un nouveau arbre arb3-*/
  void Preordre_preordre (Pointer_Ai *P , Pointer_Ai *Q , Pointer_Ai *Arb3)
    {
      /** Local variables **/
      Pointer_Ai Tete_p=NULL;
      Pointer_Ai Tete_q=NULL;
      Pointer_PAi Stack_p=NULL;
      Pointer_PAi Stack_q=NULL;
      int _Px1;
      int _Px2;
      int _Px3;
      int _Px4;

      /** Body of function **/
     Tete_p  =  *P ;
     Tete_q  =  *Q ;
     Createstack_PAi (& Stack_p ) ;
     Createstack_PAi (& Stack_q ) ;
     Allocate_node_Ai (& *Arb3 ) ;
     if( Node_value_Ai ( *P ) < Node_value_Ai ( *Q ))   {
       Ass_node_val_Ai ( *Arb3 , Node_value_Ai ( *P ) ) ;
       Next_preordre ( & *P , & Stack_p ) ;
       }
     else
       {
       Ass_node_val_Ai ( *Arb3 , Node_value_Ai ( *Q ) ) ;
       Next_preordre ( & *Q , & Stack_q ) ;

     } ;
     while( ( ( *P != NULL ) || ( Empty_stack_PAi ( Stack_p ) == False ) ) || ( ( *Q != NULL ) || ( Empty_stack_PAi ( Stack_q ) == False ) ))  {
       if( ( ( *P != NULL ) || ( Empty_stack_PAi ( Stack_p ) == False ) ) && ( ( *Q != NULL ) || ( Empty_stack_PAi ( Stack_q ) == False ) ))   {
         if( Node_value_Ai ( *P ) < Node_value_Ai ( *Q ))   {
           _Px1 =  Node_value_Ai ( *P ) ;
           Bst_insert ( & *Arb3 , &_Px1) ;
           Next_preordre ( & *P , & Stack_p ) ;
           }
         else
           {
           _Px2 =  Node_value_Ai ( *Q ) ;
           Bst_insert ( & *Arb3 , &_Px2) ;
           Next_preordre ( & *Q , & Stack_q ) ;

         } ;
         }
       else
         {
         if( ( *P == NULL ) && ( Empty_stack_PAi ( Stack_p ) == True ))   {
           _Px3 =  Node_value_Ai ( *Q ) ;
           Bst_insert ( & *Arb3 , &_Px3) ;
           Next_preordre ( & *Q , & Stack_q ) ;
           }
         else
           {
           if( ( *Q == NULL ) && ( Empty_stack_PAi ( Stack_q ) == True ))   {
             _Px4 =  Node_value_Ai ( *P ) ;
             Bst_insert ( & *Arb3 , &_Px4) ;
             Next_preordre ( & *P , & Stack_p ) ;

           } ;

         } ;

       } ;

     } ;
     *P  =  Tete_p ;
     *Q  =  Tete_q ;

    }
  /*-procedure qui fusion deux arb p et q selon inordre pour p ,et preordre pour q dans un nouveau arbre arb3-*/
  void Inordre_preordre (Pointer_Ai *P , Pointer_Ai *Q , Pointer_Ai *Arb3)
    {
      /** Local variables **/
      Pointer_Ai Tete_p=NULL;
      Pointer_Ai Tete_q=NULL;
      Pointer_PAi Stack_p=NULL;
      Pointer_PAi Stack_q=NULL;
      bool T;
      int _Px1;
      int _Px2;
      int _Px3;
      int _Px4;

      /** Body of function **/
     Tete_p  =  *P ;
     Tete_q  =  *Q ;
     T  =  False ;
     Createstack_PAi (& Stack_p ) ;
     Createstack_PAi (& Stack_q ) ;
     Allocate_node_Ai (& *Arb3 ) ;
     Next_inordre ( & *P , & T , & Stack_p ) ;
     if( Node_value_Ai ( *P ) < Node_value_Ai ( *Q ))   {
       Ass_node_val_Ai ( *Arb3 , Node_value_Ai ( *P ) ) ;
       Next_inordre ( & *P , & T , & Stack_p ) ;
       }
     else
       {
       Ass_node_val_Ai ( *Arb3 , Node_value_Ai ( *Q ) ) ;
       Next_preordre ( & *Q , & Stack_q ) ;

     } ;
     while( ( ( *P != NULL ) || ( Empty_stack_PAi ( Stack_p ) == False ) ) || ( ( *Q != NULL ) || ( Empty_stack_PAi ( Stack_q ) == False ) ))  {
       if( ( ( *P != NULL ) || ( Empty_stack_PAi ( Stack_p ) == False ) ) && ( ( *Q != NULL ) || ( Empty_stack_PAi ( Stack_q ) == False ) ))   {
         if( Node_value_Ai ( *P ) < Node_value_Ai ( *Q ))   {
           _Px1 =  Node_value_Ai ( *P ) ;
           Bst_insert ( & *Arb3 , &_Px1) ;
           Next_inordre ( & *P , & T , & Stack_p ) ;
           }
         else
           {
           _Px2 =  Node_value_Ai ( *Q ) ;
           Bst_insert ( & *Arb3 , &_Px2) ;
           Next_preordre ( & *Q , & Stack_q ) ;

         } ;
         }
       else
         {
         if( ( *P == NULL ) && ( Empty_stack_PAi ( Stack_p ) == True ))   {
           _Px3 =  Node_value_Ai ( *Q ) ;
           Bst_insert ( & *Arb3 , &_Px3) ;
           Next_preordre ( & *Q , & Stack_q ) ;
           }
         else
           {
           if( ( *Q == NULL ) && ( Empty_stack_PAi ( Stack_q ) == True ))   {
             _Px4 =  Node_value_Ai ( *P ) ;
             Bst_insert ( & *Arb3 , &_Px4) ;
             Next_inordre ( & *P , & T , & Stack_p ) ;

           } ;

         } ;

       } ;

     } ;
     *P  =  Tete_p ;
     *Q  =  Tete_q ;

    }
  /*-procedure qui fusion deux arb p et q selon postordre pour p ,et postordre pour q dans un nouveau arbre arb3-*/
  void Postordre_postordre (Pointer_Ai *P , Pointer_Ai *Q , Pointer_Ai *Arb3)
    {
      /** Local variables **/
      Pointer_Ai Tete_p=NULL;
      Pointer_Ai Tete_q=NULL;
      Pointer_Ai Sauv_p=NULL;
      Pointer_Ai Sauv_q=NULL;
      Pointer_Ai K=NULL;
      bool Test_p;
      bool Test_q;
      Pointer_PAi Stack_p=NULL;
      Pointer_PAi Stack_q=NULL;
      int _Px1;
      int _Px2;
      int _Px3;
      int _Px4;

      /** Body of function **/
     Tete_p  =  *P ;
     Tete_q  =  *Q ;
     Test_p  =  False ;
     Test_q  =  False ;
     Sauv_p  =  NULL ;
     Sauv_q  =  NULL ;
     Createstack_PAi (& Stack_p ) ;
     Createstack_PAi (& Stack_q ) ;
     Allocate_node_Ai (& *Arb3 ) ;
     K  =  *P ;
     Push_PAi (& Stack_p , K ) ;
     *P  =  Lc_Ai ( *P ) ;
     K  =  *Q ;
     Push_PAi (& Stack_q , K ) ;
     *Q  =  Lc_Ai ( *Q ) ;
     Next_postordre ( & *P , & Sauv_p , & Test_p , & Stack_p ) ;
     Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;
     if( Node_value_Ai ( *P ) < Node_value_Ai ( *Q ))   {
       Ass_node_val_Ai ( *Arb3 , Node_value_Ai ( *P ) ) ;
       Next_postordre ( & *P , & Sauv_p , & Test_p , & Stack_p ) ;
       }
     else
       {
       Ass_node_val_Ai ( *Arb3 , Node_value_Ai ( *Q ) ) ;
       Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;

     } ;
     while( ( ( *P != NULL ) || ( Empty_stack_PAi ( Stack_p ) == False ) ) || ( ( *Q != NULL ) || ( Empty_stack_PAi ( Stack_q ) == False ) ))  {
       if( ( ( *P != NULL ) || ( Empty_stack_PAi ( Stack_p ) == False ) ) && ( ( *Q != NULL ) || ( Empty_stack_PAi ( Stack_q ) == False ) ))   {
         if( Node_value_Ai ( *P ) < Node_value_Ai ( *Q ))   {
           _Px1 =  Node_value_Ai ( *P ) ;
           Bst_insert ( & *Arb3 , &_Px1) ;
           Next_postordre ( & *P , & Sauv_p , & Test_p , & Stack_p ) ;
           }
         else
           {
           _Px2 =  Node_value_Ai ( *Q ) ;
           Bst_insert ( & *Arb3 , &_Px2) ;
           Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;

         } ;
         }
       else
         {
         if( ( *P == NULL ) && ( Empty_stack_PAi ( Stack_p ) == True ))   {
           _Px3 =  Node_value_Ai ( *Q ) ;
           Bst_insert ( & *Arb3 , &_Px3) ;
           Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;
           }
         else
           {
           if( ( *Q == NULL ) && ( Empty_stack_PAi ( Stack_q ) == True ))   {
             _Px4 =  Node_value_Ai ( *P ) ;
             Bst_insert ( & *Arb3 , &_Px4) ;
             Next_postordre ( & *P , & Sauv_p , & Test_p , & Stack_p ) ;

           } ;

         } ;

       } ;

     } ;
     *P  =  Tete_p ;
     *Q  =  Tete_q ;

    }
  /*-procedure qui fusion deux arb p et q selon inordre pour p ,et postordre pour q dans un nouveau arbre arb3-*/
  void Inordre_postordre (Pointer_Ai *P , Pointer_Ai *Q , Pointer_Ai *Arb3)
    {
      /** Local variables **/
      Pointer_Ai Tete_p=NULL;
      Pointer_Ai Tete_q=NULL;
      Pointer_Ai Sauv_q=NULL;
      Pointer_Ai K=NULL;
      bool Test_q;
      bool Test_p;
      Pointer_PAi Stack_q=NULL;
      Pointer_PAi Stack_p=NULL;
      int _Px1;
      int _Px2;
      int _Px3;
      int _Px4;

      /** Body of function **/
     Tete_p  =  *P ;
     Tete_q  =  *Q ;
     Test_q  =  False ;
     Test_p  =  False ;
     Sauv_q  =  NULL ;
     Createstack_PAi (& Stack_p ) ;
     Createstack_PAi (& Stack_q ) ;
     Allocate_node_Ai (& *Arb3 ) ;
     K  =  *Q ;
     Push_PAi (& Stack_q , K ) ;
     *Q  =  Lc_Ai ( *Q ) ;
     Next_inordre ( & *P , & Test_p , & Stack_p ) ;
     Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;
     if( Node_value_Ai ( *P ) < Node_value_Ai ( *Q ))   {
       Ass_node_val_Ai ( *Arb3 , Node_value_Ai ( *P ) ) ;
       Next_inordre ( & *P , & Test_p , & Stack_p ) ;
       }
     else
       {
       Ass_node_val_Ai ( *Arb3 , Node_value_Ai ( *Q ) ) ;
       Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;

     } ;
     while( ( ( *P != NULL ) || ( Empty_stack_PAi ( Stack_p ) == False ) ) || ( ( *Q != NULL ) || ( Empty_stack_PAi ( Stack_q ) == False ) ))  {
       if( ( ( *P != NULL ) || ( Empty_stack_PAi ( Stack_p ) == False ) ) && ( ( *Q != NULL ) || ( Empty_stack_PAi ( Stack_q ) == False ) ))   {
         if( Node_value_Ai ( *P ) < Node_value_Ai ( *Q ))   {
           _Px1 =  Node_value_Ai ( *P ) ;
           Bst_insert ( & *Arb3 , &_Px1) ;
           Next_inordre ( & *P , & Test_p , & Stack_p ) ;
           }
         else
           {
           _Px2 =  Node_value_Ai ( *Q ) ;
           Bst_insert ( & *Arb3 , &_Px2) ;
           Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;

         } ;
         }
       else
         {
         if( ( *P == NULL ) && ( Empty_stack_PAi ( Stack_p ) == True ))   {
           _Px3 =  Node_value_Ai ( *Q ) ;
           Bst_insert ( & *Arb3 , &_Px3) ;
           Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;
           }
         else
           {
           if( ( *Q == NULL ) && ( Empty_stack_PAi ( Stack_q ) == True ))   {
             _Px4 =  Node_value_Ai ( *P ) ;
             Bst_insert ( & *Arb3 , &_Px4) ;
             Next_inordre ( & *P , & Test_p , & Stack_p ) ;

           } ;

         } ;

       } ;

     } ;
     *P  =  Tete_p ;
     *Q  =  Tete_q ;

    }
  /*-procedure qui fusion deux arb p et q selon preordre pour p ,et postordre pour q dans un nouveau arbre arb3-*/
  void Preordre_postordre (Pointer_Ai *P , Pointer_Ai *Q , Pointer_Ai *Arb3)
    {
      /** Local variables **/
      Pointer_Ai Tete_p=NULL;
      Pointer_Ai Tete_q=NULL;
      Pointer_Ai Sauv_q=NULL;
      Pointer_Ai K=NULL;
      bool Test_q;
      Pointer_PAi Stack_p=NULL;
      Pointer_PAi Stack_q=NULL;
      int _Px1;
      int _Px2;
      int _Px3;
      int _Px4;

      /** Body of function **/
     Tete_p  =  *P ;
     Tete_q  =  *Q ;
     Test_q  =  False ;
     Sauv_q  =  NULL ;
     Createstack_PAi (& Stack_p ) ;
     Createstack_PAi (& Stack_q ) ;
     Allocate_node_Ai (& *Arb3 ) ;
     K  =  *Q ;
     Push_PAi (& Stack_q , K ) ;
     *Q  =  Lc_Ai ( *Q ) ;
     Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;
     if( Node_value_Ai ( *P ) < Node_value_Ai ( *Q ))   {
       Ass_node_val_Ai ( *Arb3 , Node_value_Ai ( *P ) ) ;
       Next_preordre ( & *P , & Stack_p ) ;
       }
     else
       {
       Ass_node_val_Ai ( *Arb3 , Node_value_Ai ( *Q ) ) ;
       Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;

     } ;
     while( ( ( *P != NULL ) || ( Empty_stack_PAi ( Stack_p ) == False ) ) || ( ( *Q != NULL ) || ( Empty_stack_PAi ( Stack_q ) == False ) ))  {
       if( ( ( *P != NULL ) || ( Empty_stack_PAi ( Stack_p ) == False ) ) && ( ( *Q != NULL ) || ( Empty_stack_PAi ( Stack_q ) == False ) ))   {
         if( Node_value_Ai ( *P ) < Node_value_Ai ( *Q ))   {
           _Px1 =  Node_value_Ai ( *P ) ;
           Bst_insert ( & *Arb3 , &_Px1) ;
           Next_preordre ( & *P , & Stack_p ) ;
           }
         else
           {
           _Px2 =  Node_value_Ai ( *Q ) ;
           Bst_insert ( & *Arb3 , &_Px2) ;
           Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;

         } ;
         }
       else
         {
         if( ( *P == NULL ) && ( Empty_stack_PAi ( Stack_p ) == True ))   {
           _Px3 =  Node_value_Ai ( *Q ) ;
           Bst_insert ( & *Arb3 , &_Px3) ;
           Next_postordre ( & *Q , & Sauv_q , & Test_q , & Stack_q ) ;
           }
         else
           {
           if( ( *Q == NULL ) && ( Empty_stack_PAi ( Stack_q ) == True ))   {
             _Px4 =  Node_value_Ai ( *P ) ;
             Bst_insert ( & *Arb3 , &_Px4) ;
             Next_preordre ( & *P , & Stack_p ) ;

           } ;

         } ;

       } ;

     } ;
     *P  =  Tete_p ;
     *Q  =  Tete_q ;

    }
  /*------procedure qui renvoie le nombre des noueds dans chaque niveau dans un fichier-----*/
  int Noeud_par_niv_max (Pointer_Ai *P)
    {
      /** Local variables **/
      int Cpt;
      int K;
      int I;
      int Mx;
      Pointer_FAi F=NULL;

      /** Body of function **/
     Createqueue_FAi (& F ) ;
     Enqueue_FAi ( F , *P ) ;
     Cpt  =  1 ;
     Mx  =  Cpt ;
     while( ( Empty_queue_FAi ( F ) == False ))  {
       K  =  0 ;
       for( I  =  1 ;I <=  Cpt ; ++I) {
         if( ( Empty_queue_FAi ( F ) == False ))   {
           Dequeue_FAi ( F , &*P ) ;

         } ;
         if( Lc_Ai ( *P ) != NULL)   {
           Enqueue_FAi ( F , Lc_Ai ( *P ) ) ;
           K  =  K + 1 ;

         } ;
         if( Rc_Ai ( *P ) != NULL)   {
           Enqueue_FAi ( F , Rc_Ai ( *P ) ) ;
           K  =  K + 1 ;

         } ;

       } ;
       Cpt  =  K ;
       if( Cpt > Mx)   {
         Mx  =  Cpt ;

       } ;

     } ;
     return Mx;

    }
  /*---------hauter maximal d'un arb---------------------*/
  int  Hauteur_max (Pointer_Ai *P)
    {
      /** Local variables **/
      int  Hauteur_max2 ;
     Pointer_Ai _Px1=NULL;
      Pointer_Ai _Px2=NULL;

      /** Body of function **/
     if( *P == NULL)   {
       Hauteur_max2  =  - 1 ;
       }
     else
       {
       _Px1 =  Lc_Ai ( *P ) ;
       _Px2 =  Rc_Ai ( *P ) ;
       Hauteur_max2  =  1 + Max ( Hauteur_max ( &_Px1) , Hauteur_max ( &_Px2) ) ;

     } ;

     return Hauteur_max2 ;
    }
  /*---------hauter minimal d'un arb---------------------*/
  int  Hauteur_min (Pointer_Ai *P)
    {
      /** Local variables **/
      int  Hauteur_min2 ;
     Pointer_Ai _Px1=NULL;
      Pointer_Ai _Px2=NULL;

      /** Body of function **/
     if( *P == NULL)   {
       Hauteur_min2  =  -1 ;
       }
     else
       {
       _Px1 =  Lc_Ai ( *P ) ;
       _Px2 =  Rc_Ai ( *P ) ;
       Hauteur_min2  =  1 + Min ( Hauteur_min ( &_Px1) , Hauteur_min ( &_Px2) ) ;

     } ;

     return Hauteur_min2 ;
    }
  /*---------------balance d'une arb (n'est pas une AVL!!)--------------*/
  int  Balance (Pointer_Ai *P)
    {
      /** Local variables **/
      int  Balance2 ;
     Pointer_Ai _Px1=NULL;
      Pointer_Ai _Px2=NULL;

      /** Body of function **/
     _Px1 =  Lc_Ai ( *P ) ;
     _Px2 =  Rc_Ai ( *P ) ;
     Balance2  =  Hauteur_max ( &_Px1) - Hauteur_max ( &_Px2) ;

     return Balance2 ;
    }
  /*---------------procedure qui cree une ARB A �  n noueds donnée----------------------*/
  void Generation_de_arbre (Pointer_Ai *A , int *N)
    {
      /** Local variables **/
      int Nb;
      int J;

      /** Body of function **/
     Allocate_node_Ai (& *A ) ;
     Nb  =  Aleanombre(50000 ) ;
     Ass_node_val_Ai ( *A , Nb ) ;
     for( J  =  1 ;J <=  ( *N - 1 ) ; ++J) {
       Nb  =  Aleanombre(50000 ) ;
       Bst_insert_sans_dup ( & *A , & Nb ) ;

     } ;
    }

  int main(int argc, char *argv[])
    {
        clock_t start, end;
double execution_time;
        int tab_haut_max[50][5];
        int tab_balance[50][5];
        int tab_noeud_par_niv[50][5];
        double tab_temps_execution[50][5];
     srand(time(NULL));
     T = malloc(100 * sizeof(int));
     N  =  10000 ;
     M  =  50 ;
     for( I  =  1 ;I <=  M ; ++I) {
       Generation_de_arbre ( & A1 , & N ) ;
       Generation_de_arbre ( & A2 , & N ) ;
       for( C  =  1 ;C <=  5 ; ++C) {
         if( C == 1)   {
                start = clock();
           Inordre_preordre ( & A1 , & A2 , & A3 ) ;
         end = clock();
         execution_time = ((double)(end - start))/CLOCKS_PER_SEC;
           if (I==1){
                printf("------------------------exemple-------------------------------\n");
           printf("inordre-preordre : \n");
           printf("temps d''execution : %f s\n",execution_time);
           printf("balance : %d \n",Balance(&A3));
           printf("hauteur max : %d \n",Hauteur_max(&A3)) ;
           printf("nombre des noeuds max par niveau : %d \n\n",Noeud_par_niv_max(&A3));
           }
           tab_haut_max[I][C]=Hauteur_max(&A3);
           tab_balance[I][C]=Balance(&A3);
           tab_noeud_par_niv[I][C]=Noeud_par_niv_max(&A3);
           tab_temps_execution[I][C]=execution_time;
         }
         else
           {
           if( C == 2)   {
                start = clock();
             Inordre_postordre ( & A1 , & A2 , & A3 ) ;
           end = clock();
           execution_time = ((double)(end - start))/CLOCKS_PER_SEC;
             if (I==1){
           printf("inordre-postordre : \n");
           printf("temps d''execution : %f s\n",execution_time);
           printf("balance : %d \n",Balance(&A3));
           printf("hauteur max : %d \n",Hauteur_max(&A3)) ;
           printf("nombre des noeuds max par niveau : %d \n\n",Noeud_par_niv_max(&A3));
           }
           tab_haut_max[I][C]=Hauteur_max(&A3);
           tab_balance[I][C]=Balance(&A3);
           tab_noeud_par_niv[I][C]=Noeud_par_niv_max(&A3);
           tab_temps_execution[I][C]=execution_time;
             }
           else
             {
             if( C == 3)   {
                    start = clock();
               Preordre_preordre ( & A1 , & A2 , & A3 ) ;
             end = clock();
             execution_time = ((double)(end - start))/CLOCKS_PER_SEC;
               if (I==1){
           printf("preordre-preordre : \n");
           printf("temps d''execution : %f s\n",execution_time);
           printf("balance : %d \n",Balance(&A3));
           printf("hauteur max : %d \n",Hauteur_max(&A3)) ;
           printf("nombre des noeuds max par niveau : %d \n\n",Noeud_par_niv_max(&A3));
           }
           tab_haut_max[I][C]=Hauteur_max(&A3);
           tab_balance[I][C]=Balance(&A3);
           tab_noeud_par_niv[I][C]=Noeud_par_niv_max(&A3);
           tab_temps_execution[I][C]=execution_time;
               }
             else
               {
               if( C == 4)   {
                    start = clock();
                 Postordre_postordre ( & A1 , & A2 , & A3 ) ;
               end = clock();
               execution_time = ((double)(end - start))/CLOCKS_PER_SEC;
                   if (I==1){
           printf("postrdre-postordre : \n");
           printf("temps d''execution : %f s\n",execution_time);
           printf("balance : %d \n",Balance(&A3));
           printf("hauteur max : %d \n",Hauteur_max(&A3)) ;
           printf("nombre des noeuds max par niveau : %d \n\n",Noeud_par_niv_max(&A3));
           }
           tab_haut_max[I][C]=Hauteur_max(&A3);
           tab_balance[I][C]=Balance(&A3);
           tab_noeud_par_niv[I][C]=Noeud_par_niv_max(&A3);
           tab_temps_execution[I][C]=execution_time;
                 }
               else
                 {
                 if( C == 5)   {
                        start = clock();
                   Preordre_postordre ( & A1 , & A2 , & A3 ) ;
                 end = clock();
                 execution_time = ((double)(end - start))/CLOCKS_PER_SEC;
                     if (I==1){
           printf("prerdre-postordre : \n");
           printf("temps d''execution : %f s\n",execution_time);
           printf("balance : %d \n",Balance(&A3));
           printf("hauteur max : %d \n",Hauteur_max(&A3)) ;
           printf("nombre des noeuds max par niveau : %d \n",Noeud_par_niv_max(&A3));
           printf("---------------------------------------------------------------------\n");
           printf("vous devez attendre s'il vous plait parceque le program prend entre 100s - 150s ");
           }
           tab_haut_max[I][C]=Hauteur_max(&A3);
           tab_balance[I][C]=Balance(&A3);
           tab_noeud_par_niv[I][C]=Noeud_par_niv_max(&A3);
           tab_temps_execution[I][C]=execution_time;

                 } ;

               } ;

             } ;

           } ;

         } ;

       } ;

     } ;


      system("PAUSE");
      return 0;
    }
