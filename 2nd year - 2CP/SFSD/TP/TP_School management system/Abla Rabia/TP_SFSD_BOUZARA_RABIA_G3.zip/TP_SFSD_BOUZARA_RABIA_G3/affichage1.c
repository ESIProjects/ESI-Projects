#include "affichage1.h"
#include <windows.h>
void Affichage()
{
    system("cls");
    printf("\n\n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),5);
    printf("\n\n\n");
    printf("        ___________________________________________________________________________________________________________ \n");
    printf("       |                                                                                                           |\n");
    printf("       |  $$$$$$$$   $$$$   $$$$$$$$   $$    $$     $$  $$    $$$$$$$$   $$    $$   $    $   $$$$$$$$    ##   ##   |\n");
    printf("       |  $$      $   $$    $$         $ $   $$      $  $     $$         $ $   $$   $    $   $$          ##   ##   |\n");
    printf("       |  $$$$$$$$    $$    $$$$$$$$   $  $  $$      $  $     $$$$$$$$   $  $  $$   $    $   $$$$$$$$    ##   ##   |\n");
    printf("       |  $$      $   $$    $$         $   $ $$      $  $     $$         $   $ $$   $    $   $$                    |\n" );
    printf("       |  $$$$$$$$   $$$$   $$$$$$$$   $    $$$       $$      $$$$$$$$   $    $$$   $$$$$$   $$$$$$$$    ##   ##   |\n");
    printf("       |___________________________________________________________________________________________________________|\n\n\n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
    printf("\n");
    printf("                                %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",201,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,187);
    printf("                                %c     Notre programme vous donne la possibilite de    %c\n",186,186);
    printf("                                %c     bien manipuler les fichiers scolaires d'une     %c\n",186,186);
    printf("                                %c     ecole  primaire  a l'aide de deux structures !  %c\n",186,186);
    printf("                                %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",200,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,188);
    printf(" \n\n                                     Appuyer sur la touche ENTRER  pour continuer ! ");
    getchar();
    system("cls");
    printf("\n\n\n\n\n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),1);
    printf("                       %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",201,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,203,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,187);
    printf("                       %c                                    %c                                   %c\n",186,186,186                           );
    printf("                       %c    $$$$$$$     $$$$$$$$$     $$    %c             BOUZARA Hadjer        %c\n",186,186,186);
    printf("                       %c    $$          $$                  %c             RABIA Abla            %c\n",186,186,186);
    printf("                       %c    $$$$$$$     $$$$$$$$$     $$    %c             GROUPE : 03           %c\n",186,186,186);
    printf("                       %c    $$                 $$     $$    %c             2022|2023             %c\n",186,186,186);
    printf("                       %c    $$$$$$$     $$$$$$$$$     $$    %c                                   %c\n",186,186,186);
    printf("                       %c                                    %c                                   %c\n",186,186,186);
    printf("                       %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",200,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,202,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,188);
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),5);
    printf("                                %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",201,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,187);
    printf("                                %c   ECOLE   NATIONALE   SUPERIEURE   D'INFORMATIQUE   %c\n",186,186);
    printf("                                %c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n",200,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,188);
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
        printf("\n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
    printf("                                         Merci d'avoir choisir notre application ! ");
    printf(" \n\n                                       Appuyer sur la touche ENTRER  pour continuer ! ");
    getchar();

}
