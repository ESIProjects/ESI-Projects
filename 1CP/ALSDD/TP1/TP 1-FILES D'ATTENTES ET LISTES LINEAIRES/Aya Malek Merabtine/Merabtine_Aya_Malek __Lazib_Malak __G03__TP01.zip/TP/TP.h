#ifndef TP_H_INCLUDED
#define TP_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

// Les D�clarations
#define MAX_WORD_SIZE 50
#define MAX_NUM_WORDS 1000
#define MAX_WORDS 1000
#define NUM_LETTERS 26
#define MAX_WORD_LEN 20

//**************************Structures de la machine abstraite***************************
struct Noeud
{
int val ;
struct Noeud *Suiv ;
};

struct liste {
	struct Noeud *tete;
	struct Noeud *queu;
	int taille;
} ;
//**********************************************************************************************
typedef struct Maillon {
    char* mot;
    struct  Maillon* suivant;
    struct  Maillon* prec;
} Maillon;

typedef struct {
    Maillon* head;
    Maillon* tail;
} List;


List alphabet[26];
typedef struct SyllabeMaillon {
    char* syllabe;
    struct SyllabeMaillon* suivant;
} SyllabeMaillon;
typedef struct ListMaillon {
    char* mot;
    struct ListMaillon* suivant;
    struct ListMaillon* prec;
    SyllabeMaillon* syllabes;
} ListMaillon;
typedef struct MotMaillon {
    char mot[MAX_WORD_LEN];
    char nouveauMot[MAX_WORD_LEN];
    struct MotMaillon *suivant;
} MotMaillon;

//*****************************************Machine abstraite************************************************
// Fonction pour allouer (r�server) un espace m�moire pour la structure Noeud
struct Noeud *Allouer ( ) ;

// Fonction pour d�finir la valeur de la structure Noeud
void Affval(struct Maillon *P, int v);

// Fonction pour d�finir la valeur d�une structure d�un Noeud
void Affadr( struct Maillon *P, struct Maillon *Q) ;

// Fonction pour d�terminer le pointeur suivant de la structure Noeud
struct Maillon *Suivant( struct Maillon *P) ;

// Fonction pour donner la valeur stock�e dans un structure noeud
int Valeur( struct Maillon *P) ;
//**********************************************************************************************************
// Fonction pour ajouter un mot � une liste
void add_word_to_list(char* mot, List* list);

// Fonction pour ajouter un mot d�un tableau d� alphabet[] � une liste
void add_word_to_alphabet(char* mot);

// Fonction pour retirer les slashes
char* remove_slashes(char* mot);

// Fonction pour extraire les mots du fichier et les mettre tri�s dans une liste bidirectionnelle
void mots_du_fichier();

// Fonction pour cr�er une liste bidirectionnelle
ListMaillon * createBidirectionalList();

// Fonction pour afficher la liste bidirectionnelle
void PrintfBidirectionalList (head);

// Fonction pour l�ajout d�un mot
void addWordToList(ListMaillon** head, char* nouveau_mot);

// Fonction pour la suppression d�un mot
void removeWordFromList(ListMaillon** head, char* word_to_remove);

//*****************************les anagrammes***********************************
// Fonction pour indiquer si deux mots sont des anagrammes entre eux
int areAnagrams(char* mot1, char* mot2);

// Fonction pour lib�rer un maillon
void removeNode(ListMaillon* maillon);

// Fonction pour extraire les anagrammes � partir d�une liste bidirectionnelle
void extractAnagrams(ListMaillon* head);

//*************************************verb/ed/ing*********************************
// Fonction pour extraire les verbes anglais de la forme mot->stem/ed/ing
void extractEnglishVerbs(ListMaillon* head);

//************************************************************************************

//**************************Les mots les plus proches lexicalement************
// Fonction pour ajouter un mot � la fin de la liste
void addWord(ListMaillon** headRef, char* mot);

// Fonction pour comparer deux mots et retourner vrai s'ils sont similaires, faux sinon
int areWordsSimilar(char* mot1, char* mot2);

// Fonction pour afficher la liste des mots similaires pour chaque mot de la liste
void printSimilarWords(ListMaillon* head);

//***********************************************************************************

//******************************in/pin/ping*****************************************
// Fonction pour trouver un s�quence de mots avec un ajout d�une lettre
int findWords(char mots[MAX_WORDS][MAX_WORD_LEN], int numMots);

// Fonction pour trouver une s�quence de mots avec un ajout d�une lettre � partir d�une liste
void findWordsFromList(ListMaillon* head);
//***********************************************************************************

//******************************prefixes/suffixes/milieu*****************************
// Fonction pour ajouter un nouveau n�ud
void addNode(ListMaillon** head, char* mot);

// Fonction pour v�rifier si le mot existe d�j� dans la liste ou pas
int isInList(ListMaillon* head, char* mot);

// Fonction pour v�rifier si un mot est form� par l�ajout  d�une s�quence de lettres  � partir d�un autre mot
int isSubsequence(char* subseq, char* mot);

// Fonction  pour g�n�rer une liste de mots de la m�me famille � partir d'un mot
ListMaillon* generateWordFamily(char* mot, ListMaillon* head, ListMaillon* excluded);

// Fonction pour indiquer si deux mots sont de la m�me famille
int isFamilyInList(ListMaillon* head, ListMaillon* family);

// Fonction pour g�n�rer les listes des mots de la m�me famille pour chaque mot de la liste
void generateWordFamilies(ListMaillon* head);
//***************************************************************************************


// Fonction pour extraire les mots du fichier avec les slaches  et les mettre tri�s dans une liste bidirectionnelle
void mots_du_fichieravecSlaches();

// Fonction pour afficher les syllabes et le nombre de lettres de chaque mot
void traiter_mots_liste(ListMaillon *tete);

// Fonction pour compter le nombre de consonnes dans un mot
int count_consonants(char *mot);

// Fonction pour compter le nombre de voyelles dans un mot
int count_vowels(char *mot);

// Fonction pour retourner le nombre de consonnes et de voyelles pour chaque mot de la liste
void process_list(ListMaillon *tete);

// Fonction pour indiquer si le mot est form� d�une s�quence de lettres selon l�ordre alphab�tique
bool isAlphabetical(ListMaillon* maillon);

// Fonction pour extraire les mots du fichier  et les mettre tri�s dans une liste bidirectionnelle sans affichage
void mots_du_fichier_sans_affichage();

#endif // TP_H_INCLUDED


