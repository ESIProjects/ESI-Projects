#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

// Les d�clarations
#define MAX_WORD_SIZE 50
#define MAX_NUM_WORDS 1000
#define NUM_LETTERS 26
#define MAX_WORDS 100
#define MAX_WORD_LEN 20
//**************************Structures de la machine abstraite***************************
struct Noeud
{
int val ;
struct Noeud *Suiv ;
};

struct liste {
	struct Noeud *tete;
	struct Noeud *queu;
	int taille;
} ;
//**********************************************************************************************
typedef struct Maillon {
    char* mot;
    struct  Maillon* suivant;
    struct  Maillon* prec;
} Maillon;

typedef struct {
    Maillon* head;
    Maillon* tail;
} List;

List alphabet[26];
typedef struct SyllabeMaillon {
    char* syllabe;
    struct SyllabeMaillon* suivant;
} SyllabeMaillon;
typedef struct ListMaillon {
    char* mot;
    struct ListMaillon* suivant;
    struct ListMaillon* prec;
    SyllabeMaillon* syllabes;
} ListMaillon;
typedef struct MotMaillon {
    char mot[MAX_WORD_LEN];
    char nouveauMot[MAX_WORD_LEN];
    struct MotMaillon *suivant;
} MotMaillon;

//*****************************************Machine abstraite*******************************************************
struct Noeud *Allouer ( )
{
return ((struct Noeud *) malloc( sizeof(struct Noeud)));
}


void Affval(struct Noeud *P, int v)
{ P->val =v; }


void Affadr( struct Noeud *P, struct Noeud *Q)
{ P->Suiv = Q; }


struct Noeud *Suivant( struct Noeud *P)
{ return( P->Suiv ); }


int Valeur( struct Noeud *P)
{ return( P->val) ; }


//*****************************************************************************************************************
void add_word_to_list(char* mot, List* list) {
    Maillon* nouveau_maillon = malloc(sizeof(Maillon));
    nouveau_maillon->mot = mot;
    nouveau_maillon->suivant = NULL;
    nouveau_maillon->prec = NULL;

    if (list->head == NULL) {
        list->head = nouveau_maillon;
        list->tail = nouveau_maillon;
    } else {
        Maillon* current = list->head;
        while (current != NULL && strlen(current->mot) < strlen(mot)) {
            current = current->suivant;
        }

        if (current == NULL) {
            list->tail->suivant = nouveau_maillon;
            nouveau_maillon->prec = list->tail;
            list->tail = nouveau_maillon;
        } else if (current == list->head) {
            nouveau_maillon->suivant = list->head;
            list->head->prec = nouveau_maillon;
            list->head = nouveau_maillon;
        } else {
            current->prec->suivant = nouveau_maillon;
            nouveau_maillon->prec = current->prec;
            nouveau_maillon->suivant = current;
            current->prec = nouveau_maillon;
        }
    }
}
void add_word_to_alphabet(char* mot) {
    int index = tolower(mot[0]) - 'a';
    add_word_to_list(mot, &alphabet[index]);
}
char* remove_slashes(char* mot) {
    int i, j;
    for (i = 0, j = 0; mot[i] != '\0'; i++) {
        if (mot[i] != '/') {
            mot[j] = mot[i];
            j++;
        }
    }
    mot[j] = '\0';
    return mot;
}

void mots_du_fichier() {
    FILE* file;
    char* filename = "words.txt";
    char mot[MAX_WORD_SIZE];
    char* mots[MAX_NUM_WORDS];
    int num_mots = 0;

    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Could not open file %s\n", filename);
        exit(1);
    }

    while (fscanf(file, "%s", mot) != EOF) {
        char* nouveau_mot = remove_slashes(mot);
        mots[num_mots] = (char*)malloc(strlen(nouveau_mot) + 1);
        strcpy(mots[num_mots], nouveau_mot);
        num_mots++;
    }

    fclose(file);

     // Initialiser les listes
    for (int i = 0; i < 26; i++) {
        alphabet[i].head = NULL;
        alphabet[i].tail = NULL;
    }

    // Lire les mots depuis un tableau

    for (int i = 0; i < num_mots; i++) {
        add_word_to_alphabet(mots[i]);
    }

    // Afficher les mots tri�s par ordre alphab�tique selon leur longueur
    for (int i = 0; i < 26; i++) {
        if (alphabet[i].head != NULL) {
            printf("%c: ", 'a' + i);
            Maillon* current = alphabet[i].head;
            while (current != NULL) {
                printf("%s ", current->mot);
                current = current->suivant;
            }
            printf("\n");
        }
    }

}
ListMaillon* head = NULL;
ListMaillon * createBidirectionalList() {
    ListMaillon* head = NULL;
    for (int i = 0; i < 26; i++) {
        ListMaillon* current = alphabet[i].head;
        while (current != NULL) {
            ListMaillon* nouveau_maillon = malloc(sizeof(ListMaillon));
            nouveau_maillon->mot = current->mot;
            nouveau_maillon->prec = NULL;
            nouveau_maillon->suivant = NULL;
            if (head == NULL) {
                head = nouveau_maillon;
            } else {
                ListMaillon* last_maillon = head;
                while (last_maillon->suivant != NULL) {
                    last_maillon = last_maillon->suivant;
                }
                last_maillon->suivant = nouveau_maillon;
                nouveau_maillon->prec = last_maillon;
            }
            current = current->suivant;
        }
    }
    return head;
}


void PrintfBidirectionalList (head){
    ListMaillon* current = head;
    while (current != NULL) {
        printf("%s <-> ", current->mot);
        current = current->suivant;
    }

}
//*****************************ajouter un mot***********************************
void addWordToList(ListMaillon** head, char* nouveau_mot) {
    ListMaillon* nouveau_maillon = malloc(sizeof(ListMaillon));
    nouveau_maillon->mot = nouveau_mot;
    nouveau_maillon->prec = NULL;
    nouveau_maillon->suivant = NULL;

    if (*head == NULL) {
        // Si la liste est vide, on ins�re le nouveau n�ud en t�te de liste.
        *head = nouveau_maillon;
    } else {
        // Sinon, on parcourt la liste jusqu'� la fin pour ins�rer le nouveau n�ud � la fin de la liste.
        ListMaillon* current = *head;
        while (current->suivant != NULL) {
            current = current->suivant;
        }
        current->suivant = nouveau_maillon;
        nouveau_maillon->prec = current;
    }
}
//*****************************supprimer un mot***********************************
void removeWordFromList(ListMaillon** head, char* word_to_remove) {
    // V�rifier si la liste est vide
    if (*head == NULL) {
        return;
    }

    // Transformer le mot � supprimer en minuscules
    char* word_lower = strdup(word_to_remove);
    for (int i = 0; i < strlen(word_to_remove); i++) {
        word_lower[i] = tolower(word_to_remove[i]);
    }

    // Trouver le n�ud � supprimer
    ListMaillon* current = *head;
    while (current != NULL) {
        // Transformer le mot courant en minuscules pour la comparaison
        char* current_lower = strdup(current->mot);
        for (int i = 0; i < strlen(current->mot); i++) {
            current_lower[i] = tolower(current->mot[i]);
        }

        if (strcmp(current_lower, word_lower) == 0) {
            break;
        }

        current = current->suivant;
    }

    // Lib�rer la m�moire allou�e pour les copies de mots en minuscules
    free(word_lower);

    if (current == NULL) {
        // Le mot n'a pas �t� trouv� dans la liste
        return;
    }

    if (current == *head) {
        // Le n�ud � supprimer est la t�te de liste
        *head = current->suivant;
    }

    // Mettre � jour les liens entre les n�uds
    if (current->prec != NULL) {
        current->prec->suivant = current->suivant;
    }
    if (current->suivant != NULL) {
        current->suivant->prec = current->prec;
    }

    // Lib�rer la m�moire occup�e par le n�ud et la copie de mot en minuscules
    free(current);

}
//*****************************les anagrammes***********************************

int areAnagrams(char* mot1, char* mot2) {
    // V�rifier d'abord si les deux mots ont la m�me longueur
    int len1 = strlen(mot1);
    int len2 = strlen(mot2);
    if (len1 != len2) {
        return 0;
    }

    // Compter le nombre d'occurrences de chaque caract�re dans chaque mot
    int count1[26] = {0};
    int count2[26] = {0};
    for (int i = 0; i < len1; i++) {
        count1[mot1[i] - 'a']++;
        count2[mot2[i] - 'a']++;
    }

    // Comparer les deux tableaux de compte
    for (int i = 0; i < 26; i++) {
        if (count1[i] != count2[i]) {
            return 0;
        }
    }

    return 1;
}
void removeNode(ListMaillon* maillon) {
    if (maillon == NULL) {
        return;
    }

    if (maillon->prec != NULL) {
        maillon->prec->suivant = maillon->suivant;
    }

    if (maillon->suivant != NULL) {
        maillon->suivant->prec = maillon->prec;
    }

    free(maillon);
}

// fonction qui extrait les mots qui sont des anagrammes � partir d'une liste bidirectionnelle
void extractAnagrams(ListMaillon* head) {
    int nblistes=0,nbmots=0;
    ListMaillon* current = head;
    while (current != NULL) {
        // Cr�er une liste cha�n�e temporaire pour stocker les anagrammes de current
        ListMaillon* temp = NULL;

        // V�rifier si le mot courant a des anagrammes
        ListMaillon* ptr = current->suivant;
        while (ptr != NULL) {
            if (areAnagrams(current->mot, ptr->mot)) {
                // Ajouter le mot ptr � la liste cha�n�e temporaire
                ListMaillon* nouveau_maillon = malloc(sizeof(ListMaillon));
                nouveau_maillon->mot = ptr->mot;
                nouveau_maillon->suivant = temp;
                temp = nouveau_maillon;

                // Supprimer le mot ptr de la liste d'origine
                removeNode(ptr);
            }
            ptr = ptr->suivant;
        }

        // Afficher la liste cha�n�e temporaire
        if (temp != NULL) {
            printf("%s <->", current->mot);
            ListMaillon* t = temp;
            while (t != NULL) {
                printf(" %s <->", t->mot);
                nbmots++;
                t = t->suivant;
            }
            printf("\n");
            nblistes++;
            nbmots++;
        }

        current = current->suivant;
    }
    printf("\n \n*********************Les statistiques***************************\n \n");
    printf("Le nombre de listes crees est : %d liste(s) \n \n ",nblistes);
    printf("Le nombre de mots stockes est : %d mot(s) \n \n",nbmots);
}
//*******************************************ed/ing*****************************************************************
// Liste des verbes anglais r�guliers
char* english_verbs[] = {"serve", "rest","cope", "run", "play", "work", "swim", "write", "read",
 "advise", "dance", "sing", "search", "boost", "Worry", "worry", "desert","rain","accept","add","admire",
 "admit","advise","afford","agree","alert","allow","amuse"
,"analyze","announce","annoy","answer","apologise","appear","applaud","appreciate",
"approve","argue","arrange","arrest","arrive","ask","attach","attack","attempt","attend",
"attract","avoid", "arrive" ,"bake" ,  "ask","attach","attack","attempt","attend","attract","avoid" ,
"balance","ban","bang","bare","bat","bathe","battle,","beam" ,"beg","behave","belong","bleach",
"bless","blind","blink","blot","blush","calculate","call","camp",
"care","carry","carve","cause","challenge","change","charge","cheat","check","cheer"
,"choke","chop","claim","clap","clean","clear","clip","collect","communicate","compare"
,"compete","complain","complete","concentrate","concern","confess","confuse","connect",
"consider","consist","damage""dance","dare","decide","decorate","delay","delight","deliver"
,"depend","describe","deserve","destroy","detect","develop","disagree","disappear",
"disapprove","discover","dislike","earn","educate","embarrass","employ","empty","encourage","end",
"enjoy","enter","entertain","escape","examine","excite","excuse","exercise","exist","expand","expect"
,"explain","explode","extend","face","fade","fail","fancy","fasten","fax","fear","fence","fetch",
"file","fill","film","fire","fit","fix","flap","flash","float","flood","flow","fold","follow","fool","force","form",
"gather","gaze","glow","glue","grab" , "identify","imagine","join" , "love" ,"manage", "mark" ,"match" ,"meet", "open",
 "order", "organize","pack","paint","pass","program","protect","use","want" };



void extractEnglishVerbs(ListMaillon* head) {
    int nblistes=0,nbmots=0;
    ListMaillon* current = head;
    while (current != NULL) {
        // V�rifier si le mot commence par un verbe anglais
        int is_english_verb = 0;
        for (int i = 0; i < sizeof(english_verbs)/sizeof(english_verbs[0]); i++) {
            if (strncmp(english_verbs[i], current->mot, strlen(english_verbs[i])) == 0) {
                is_english_verb = 1;
                break;
            }
        }
        if (is_english_verb) {
            // Extraire la partie du mot qui pr�c�de "ed" ou "ing"
            char* stem = malloc(strlen(current->mot) + 1);
            if (strlen(current->mot) > 2 && strncmp(current->mot + strlen(current->mot) - 2, "ed", 2) == 0) {
                strncpy(stem, current->mot, strlen(current->mot) - 2);
                stem[strlen(current->mot) - 2] = '\0';
            } else if (strlen(current->mot) > 3 && strncmp(current->mot + strlen(current->mot) - 3, "ing", 3) == 0) {
                strncpy(stem, current->mot, strlen(current->mot) - 3);
                stem[strlen(current->mot) - 3] = '\0';
            } else {
                strcpy(stem, current->mot);
            }

           // V�rifier si la partie extraite est un verbe anglais et afficher la forme stem correspondante
            int is_english_verb_stem = 0;
            for (int i = 0; i < sizeof(english_verbs)/sizeof(english_verbs[0]); i++) {
                if (strncmp(english_verbs[i], stem, strlen(english_verbs[i])) == 0) {
                    // retirer le "e" final si la racine du verbe se termine par un "e"
                    if (stem[strlen(stem)-1] == 'e') {
                        stem[strlen(stem)-1] = '\0';

                    printf("%s -> %se, %sed, %sing\n", current->mot, stem, stem, stem);
                    nbmots++;
                    nbmots++;
                    }
                    else {
                            printf("%s -> %s, %sed, %sing\n", current->mot, stem, stem, stem);
                            nbmots++;
                            nbmots++;
                    }
                    is_english_verb_stem = 1;
                    break;
                }
            }
            if (!is_english_verb_stem) {
                printf("%s\n", current->mot);
            }

            nblistes++;
           nbmots++;
            free(stem);
        }


        current = current->suivant;

    }
    printf("\n \n*********************Les statistiques***************************\n \n");
    printf(" \n Le nombre de listes crees est: %d liste(s) \n \n ", nblistes);
    printf("Le nombre de mots stockes est : %d mot(s) \n \n",nbmots);
}


//************************************Les mots les plus proches lexicalement******************************************
// Fonction pour ajouter un mot � la fin de la liste
void addWord(ListMaillon** headRef, char* mot) {
    ListMaillon* nouveauMot = (ListMaillon*) malloc(sizeof(ListMaillon));
   nouveauMot->mot = mot;
   nouveauMot->suivant = NULL;

    if (*headRef == NULL) {
        *headRef = nouveauMot;
    } else {
        ListMaillon* current = *headRef;
        while (current->suivant != NULL) {
            current = current->suivant;
        }
        current->suivant = nouveauMot;
    }
}
// Fonction pour comparer deux mots et retourner vrai s'ils sont similaires, faux sinon
int areWordsSimilar(char* mot1, char* mot2) {
    int len1 = strlen(mot1);
    int len2 = strlen(mot2);

    if (len1 != len2) {
        return 0;
    }

    int numDifferences = 0;
    for (int i = 0; i < len1; i++) {
        if (mot1[i] != mot2[i]) {
            numDifferences++;
        }
    }

    return (numDifferences == 1);
}
// Fonction pour afficher la liste des mots similaires pour chaque mot de la liste
void printSimilarWords(ListMaillon* head) {
    int nblistes=0,nbmots=0;
    // Parcours de la liste en ignorant le premier mot
    ListMaillon* current = head->suivant;
    while (current != NULL) {
        // Cr�ation d'une liste temporaire pour stocker les mots similaires
        ListMaillon* similarWords = NULL;

        // Parcours de la liste pour trouver les mots similaires
        ListMaillon* compare = head;
        while (compare != current) {
            if (areWordsSimilar(current->mot, compare->mot)) {
                addWord(&similarWords, compare->mot);
            }
            compare = compare->suivant;
        }

        // Si la liste des mots similaires contient au moins 1 mot, on l'affiche
        if (similarWords != NULL) {
            printf("%s<->", current->mot);
            nbmots++;
            ListMaillon* similarWord = similarWords;
            while (similarWord != NULL) {
                printf("%s", similarWord->mot);

                if (similarWord->suivant != NULL) {
                    printf(",");
                }
                similarWord = similarWord->suivant;
            }
            printf("\n");
            nblistes++;
            nbmots++;
        }

        // Lib�ration de la m�moire allou�e pour la liste temporaire des mots similaires
        ListMaillon* temp = similarWords;
        while (temp != NULL) {
            ListMaillon* suivantMaillon = temp->suivant;
            free(temp);
            temp = suivantMaillon;
        }

        current = current->suivant;
    }
    printf("\n \n*********************Les statistiques***************************\n \n");
    printf("Le nombre de listes crees est : %d liste(s) \n \n ",nblistes);
    printf("Le nombre de mots stockes est : %d mot(s) \n \n",nbmots);
}
//******************************in/pin/ping***************************

int findWords(char mots[MAX_WORDS][MAX_WORD_LEN], int numMots) {
    int i, j, k, l,nblistes=0,nbmots=0;

    for (i = 0; i < numMots; i++) {
        for (j = 0; j < (strlen(mots[i])+1); j++) {
            char temp[MAX_WORD_LEN];
            strncpy(temp, mots[i], j);
            temp[j] = '\0';
            for (k = 0; k < 26; k++) {
                char nouveauMot[MAX_WORD_LEN];
                sprintf(nouveauMot, "%s%c%s", temp, 'a'+k, mots[i]+j);

                for (l = 0; l < numMots; l++) {
                    if (strcmp(nouveauMot, mots[l]) == 0 && strcmp(nouveauMot, mots[i]) != 0) {
                        printf("%s -> %s\n", mots[i], nouveauMot);
                        nbmots++;
                        nbmots++;
                        nblistes++;

                    }
                }
            }

        }

    }
 printf("\n \n Le nombre de mots stockes est : %d mot(s)",nbmots);
return nblistes;
}


void findWordsFromList(ListMaillon* head) {

    char mots[MAX_WORDS][MAX_WORD_LEN];
    int numMots = 0;

    ListMaillon* current = head;

    while (current != NULL && numMots < MAX_WORDS) {
        strncpy(mots[numMots], current->mot, MAX_WORD_LEN);
        numMots++;
        current = current->suivant;

    }
 printf("\n ********************************Les statistiques************************\n \n");
int nblistes = findWords(mots, numMots);

    printf("\n Le nombre de listes crees est : %d liste(s)  \n \n ",nblistes);

}


//******************************prefixes/suffixes/milieu*****************************

void addNode(ListMaillon** head, char* mot) {
    // V�rifier si le mot existe d�j� dans la liste
    ListMaillon* current = *head;
    while (current != NULL) {
        if (strcmp(current->mot, mot) == 0) {
            return;
        }
        current = current->suivant;
    }

    // Cr�er un nouveau n�ud
    ListMaillon* nouveauMaillon = (ListMaillon*)malloc(sizeof(ListMaillon));
    nouveauMaillon->mot = strdup(mot);
    nouveauMaillon->suivant = NULL;

    // Si la liste est vide, faire du nouveau n�ud la t�te de liste
    if (*head == NULL) {
        *head = nouveauMaillon;
    } else {
        // Sinon, parcourir la liste jusqu'� la fin et ajouter le nouveau n�ud
        ListMaillon* current = *head;
        while (current->suivant != NULL) {
            current = current->suivant;
        }
        current->suivant = nouveauMaillon;
    }
}

int isInList(ListMaillon* head, char* mot) {
    ListMaillon* current = head;
    while (current != NULL) {
        if (strcmp(current->mot, mot) == 0) {
            return 1;
        }
        current = current->suivant;
    }
    return 0;
}
int isSubsequence(char* subseq, char* mot) {
    int subseqLen = strlen(subseq);
    int wordLen = strlen(mot);
    int i = 0, j = 0;

    while (i < subseqLen && j < wordLen) {
        if (subseq[i] == mot[j]) {
            i++;
        }
        j++;
    }

    return i == subseqLen;
}
// G�n�re une liste de mots de la m�me famille � partir d'un mot donn�
ListMaillon* generateWordFamily(char* mot, ListMaillon* head, ListMaillon* excluded) {
    ListMaillon* family = NULL;

    // Ajouter le mot initial � la liste de la m�me famille
    addNode(&family, mot);

    // Parcourir la liste des mots pour trouver ceux qui sont de la m�me famille
    ListMaillon* current = head;
    while (current != NULL) {
        if (current != excluded && !isInList(family, current->mot) && (isSubsequence(current->mot, mot) || isSubsequence(mot, current->mot))) {
            addNode(&family, current->mot);
        }
        current = current->suivant;
    }

    return family;
}


int isFamilyInList(ListMaillon* head, ListMaillon* family) {
    ListMaillon* current = head;
    while (current != NULL) {
        ListMaillon* currentFamilyMember = family;
        int isMatch = 1;
        while (currentFamilyMember != NULL) {
            if (!isInList(current, currentFamilyMember->mot)) {
                isMatch = 0;
                break;
            }
            currentFamilyMember = currentFamilyMember->suivant;
        }
        if (isMatch) {
            return 1;
        }
        current = current->suivant;
    }
    return 0;
}

void generateWordFamilies(ListMaillon* head) {
    int nblistes=0,nbmots=0;
    ListMaillon* allFamilies = NULL;

    ListMaillon* current = head;
    while (current != NULL) {
        ListMaillon* family = generateWordFamily(current->mot, head, current);

        if (family != NULL && family->suivant != NULL && !isFamilyInList(allFamilies, family)) {
            addNode(&allFamilies, family->mot);
            ListMaillon* familyCurrent = family->suivant;
            while (familyCurrent != NULL) {
                addNode(&allFamilies, familyCurrent->mot);

                familyCurrent = familyCurrent->suivant;

            }

            ListMaillon* familyMember = family;
            printf("%s", familyMember->mot);
            familyMember = familyMember->suivant;
            while (familyMember != NULL) {
                printf("<->%s", familyMember->mot);
                familyMember = familyMember->suivant;
                 nbmots++;
            }
            nbmots++;
            nblistes++;
            printf("\n");
        }

        while (family != NULL) {
            ListMaillon* temp = family;
            family = family->suivant;
            free(temp->mot);
            free(temp);
        }

        current = current->suivant;

    }

    // Free memory for all families list
    while (allFamilies != NULL) {
        ListMaillon* temp = allFamilies;
        allFamilies = allFamilies->suivant;
        free(temp->mot);
        free(temp);

    }
      printf("\n \n*********************Les statistiques***************************\n \n");
       printf(" \n Le nombre de listes crees est: %d liste(s)\n \n ", nblistes);
       printf("Le nombre de mots stockes est : %d mot(s) \n \n \n ",nbmots);
}


//************************Affficher le contenue du fichier dans une liste bidirectionelle*****************************

void mots_du_fichieravecSlaches() {
    FILE* file;
    char* filename = "words.txt";
    char mot[MAX_WORD_SIZE];
    char* mots[MAX_NUM_WORDS];
    int num_mots = 0;

    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Could not open file %s\n", filename);
        exit(1);
    }

    while (fscanf(file, "%s", mot) != EOF) {
       // char* nouveau_mot = remove_slashes(mot);
        mots[num_mots] = (char*)malloc(strlen(mot) + 1);
        strcpy(mots[num_mots],mot);
        num_mots++;
    }

    fclose(file);

     // Initialiser les listes
    for (int i = 0; i < 26; i++) {
        alphabet[i].head = NULL;
        alphabet[i].tail = NULL;
    }

    // Lire les mots depuis un tableau

    for (int i = 0; i < num_mots; i++) {
        add_word_to_alphabet(mots[i]);
    }

    // Afficher les mots tri�s par ordre alphab�tique selon leur longueur
    for (int i = 0; i < 26; i++) {
        if (alphabet[i].head != NULL) {
            printf("%c: ", 'a' + i);
            Maillon* current = alphabet[i].head;
            while (current != NULL) {
                printf("%s ", current->mot);
                current = current->suivant;
            }
            printf("\n");
        }
    }

}
//**********************
void traiter_mots_liste(ListMaillon *tete) {
    while (tete != NULL) {

        char *mot = tete->mot;
        int len = strlen(mot);
        char *nouveaumot = malloc(sizeof(char) * (len + 1));
        int j = 0;
        for (int i = 0; i < len; i++) {
            if (mot[i] != '/') {
               nouveaumot[j] = mot[i];
                j++;
            }
        }
        nouveaumot[j] = '\0';

        SyllabeMaillon* syllabes = NULL;
        int nb_syllabes = 0;
        int nb_caracteres = 0;

        char *ptr = strtok(mot, "/");
        while (ptr != NULL) {

            SyllabeMaillon* syllabe_maillon = malloc(sizeof(SyllabeMaillon));
            syllabe_maillon->syllabe = strdup(ptr);
            syllabe_maillon->suivant = NULL;
            if (syllabes == NULL) {
                syllabes = syllabe_maillon;
            } else {
                SyllabeMaillon* last_node = syllabes;
                while (last_node->suivant != NULL) {
                    last_node = last_node->suivant;
                }
                last_node->suivant = syllabe_maillon;
            }
            nb_syllabes++;
            nb_caracteres += strlen(ptr);
            ptr = strtok(NULL, "/");
        }

        printf("\n Le mot \"%s\" est decompose en %d syllabe(s) :\n", nouveaumot , nb_syllabes);
        SyllabeMaillon* syllabe_maillon = syllabes;
        for (int i = 0; i < nb_syllabes; i++) {
            printf(" %s ->",  syllabe_maillon->syllabe);
            syllabe_maillon = syllabe_maillon->suivant;
        }

        printf("\n Le mot \"%s\" contient %d lettre(s) \n" , nouveaumot , nb_caracteres);

        tete->syllabes = syllabes;
        free(nouveaumot);
        tete = tete->suivant;
    }
}

//******************************************Consonnes et voyelles************************************************


int count_consonants(char *mot) {
    int count = 0;
    int len = strlen(mot);
    for (int i = 0; i < len; i++) {
        char c = tolower(mot[i]);
        if (c >= 'b' && c <= 'z' && c != 'e' && c != 'i' && c != 'o' && c != 'u') {
            count++;
        }
    }
    return count;
}

int count_vowels(char *mot) {
    int count = 0;
    int len = strlen(mot);
    for (int i = 0; i < len; i++) {
        char c = tolower(mot[i]);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            count++;
        }
    }
    return count;
}

void process_list(ListMaillon *head) {
    ListMaillon *current = head;
    while (current != NULL) {
        remove_slashes(current->mot);
        int num_consonants = count_consonants(current->mot);
        int num_vowels = count_vowels(current->mot);
        printf("%s:se compose de %d consonne(s) et de %d voyelle(s)\n \n", current->mot, num_consonants, num_vowels);
        current = current->suivant;
    }
}

//*********************************************** word in alphabetical order**************
bool isAlphabetical(ListMaillon* maillon) {
    char* mot = maillon->mot;
    int length = strlen(mot);

    if (length < 2) {
        return true;
    }

    for (int i = 1; i < length; i++) {
        if (mot[i] < mot[i-1]) {
            return false;
        }
    }
    return true;
}

void mots_du_fichier_sans_affichage() {
    FILE* file;
    char* filename = "words.txt";
    char mot[MAX_WORD_SIZE];
    char* mots[MAX_NUM_WORDS];
    int num_mots = 0;

    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Could not open file %s\n", filename);
        exit(1);
    }

    while (fscanf(file, "%s", mot) != EOF) {
        char* nouveau_mot = remove_slashes(mot);
        mots[num_mots] = (char*)malloc(strlen(nouveau_mot) + 1);
        strcpy(mots[num_mots], nouveau_mot);
        nouveau_mot++;
    }

    fclose(file);

     // Initialiser les listes
    for (int i = 0; i < 26; i++) {
        alphabet[i].head = NULL;
        alphabet[i].tail = NULL;
    }

   // Lire les mots depuis un tableau

    for (int i = 0; i < num_mots; i++) {
        add_word_to_alphabet(mots[i]);
    }

}


