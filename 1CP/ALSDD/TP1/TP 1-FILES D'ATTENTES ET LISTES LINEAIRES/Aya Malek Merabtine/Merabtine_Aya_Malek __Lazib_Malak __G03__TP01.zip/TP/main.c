

//---------------------------------------------------------------------------------------//
//_________________________________TP1_ALSDD_2022-2023_________________________________ //

//************ R�alis� par : Lazib Malak (G03) ET Merabtine Aya Malek (G03)************ //
//---------------------------------------------------------------------------------------//


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "TP.h"

int main() {

    int choix, ch, ch1, ch2;
    char ch0;

    printf("\n ****************Notre menu principale******************************");
    printf("\n Vous veuillez choisir l'un de ces choix");
    printf("\n 0: afficher le contenu du fichier trie avec des slaches avec d'autres proprietes");
    printf("\n 1: afficher le contenu du fichier trie sans slaches");
    printf("\n 2: ajouter un mot");
    printf("\n 3: supprimer un mot");;
    printf("\n 4: Quitter\n");
    printf("\n Remarque: ........");
    printf("\n Si vous selectionnez un des choix 1 , 2 ou 3 vous avez la chance d'effectuer 5 differentes oprations portant sur les proprietes des mots anglais");
    printf("\n************************************************************************************************************************\n");
    printf("\n Entrez votre choix : ");
    scanf("%d", &choix);

    switch (choix) {  //debut pour choix

      case 0:
         printf("\n Vous avez choisi l'option 0\n");
         printf("\n le contenu du fichier dans un dictionnaire \n");
         mots_du_fichieravecSlaches();
         printf("\n le contenu du fichier dans une liste bidirectionnelle \n");
         // Appel de la fonction pour cr�er la liste bidirectionnelle
         ListMaillon * tete = createBidirectionalList();
         //Appel de la afonction pour afficher la liste bidirectionnelle
         PrintfBidirectionalList(tete);
         printf("\n*************************\n");
         printf("\n maintenant choisissez l'une de ces operations \n ");
         printf("\n***********sous menu**************\n");
         printf("\n a: Afficher les syllabes et le nombre de lettres de chaque mot");
         printf("\n b: Afficher le nombre de consonnes et de voyelles de chaque mot");
         printf("\n c:Indiquer si le mot est  forme d\'une sequence de lettre selon l\'ordre alphabetique");
         printf("\n d:Quitter \n");
         printf("\n Entrez votre choix : ");
         scanf("%s",&ch0);
         switch (ch0) {  //debut pour le ch0

         case 'a':
             printf("\n Les syllabes , ses nombres et le nombre de lettres de chaque mot sont: \n");
             traiter_mots_liste(tete);
         break;
         case 'b':
             printf("Voici le nombre de connsonnes et de voyelles de chaque mot");
            process_list(tete);
            break;
         case 'c':
             printf("Le mot est-il forme d\'une sequence de lettres selon l\'ordre alphabetique \? \n \n ");
             mots_du_fichier_sans_affichage();
             ListMaillon * head = createBidirectionalList();
             ListMaillon * current = head;
             while (current != NULL)
             {
                 printf(" %s : %s\n", current->mot, isAlphabetical(current) ? "vrai" : "Faux");
                 current = current->suivant;
                 }

                         break;
         case 'd':
            printf("\n Au revoir!");
            return 0;

                      }  //fin pour le ch0


         break; //case0-->end

      case 1:
         printf("\n Vous avez choisi l'option 1\n");
         printf("\n le contenu du fichier dans un dictionnaire \n");
         mots_du_fichier();
         printf("\n*************************\n");
         printf("\n le contenu du fichier dans une liste bidirectionnelle \n");
         // Appel de la fonction pour cr�er la liste bidirectionnelle
         ListMaillon * head = createBidirectionalList();
         //Appel de la afonction pour afficher la liste bidirectionnelle
         PrintfBidirectionalList(head);
         printf("\n*************************\n");
         printf("\n maintenant choisissez l'une de ces operations \n ");
         printf("\n***********sous menu**************\n");
         printf("\n 5: Afficher les listes des mots de la meme famille \n (Des mots formes a partir d\'autre mots en ajoutant une sous sequence de lettres) ");
         printf("\n 6: Afficher le participe passe avec \"ed\" et la forme \"ing\"");
         printf("\n 7: Afficher la sequence de mot formee par l\'ajout graduel d\'une lettre ");
         printf("\n 8: Afficer les listes des mots les plus proches lexicalement ");
         printf("\n 9: Afficher les listes des anagrammes ");
         printf("\n 10: Quitter\n");
         printf("\n Entrez votre choix : ");
         scanf("%d", &ch);
        printf("\n \n");
         switch (ch) { //debut pour le ch

            case 5:
                printf("Voici les listes des mots de la meme famille:\n \n");
               generateWordFamilies(head);
               break;
            case 6:
               printf("\n verb*ed*ing \n");
               printf("\n*************************\n");
               extractEnglishVerbs(head);

               break;
            case 7:
               printf("\n Sequence de mots formes par l\'ajout graduel d\'une lettre a la fois a gauche, a droite ou au milieu \n \n");
               findWordsFromList(head);

               break;
            case 8:
               printf("\n Les listes des mots proches lexicalement sont: \n \n ");
               printSimilarWords(head);
               break;
            case 9:
               printf("\n les listes des anagrammes sont: \n");
               ListMaillon * head = createBidirectionalList();
               extractAnagrams(head);
               break;
            case 10:
               printf("\n Au revoir !\n");
               return 0;

           default:
               printf("Choix invalide\n");

           } //fin pour le ch




        break; //case1-->end


      case 2:
         printf("\n Vous avez choisi l'option 2\n");
         printf("\n*************************\n");
         mots_du_fichier();
         // Cr�er la liste doublement cha�n�e
         head = createBidirectionalList();
         // Demander � l'utilisateur d'entrer un mot � ajouter � la liste
         char new_word[100];
         printf("\n Entrez un mot a ajouter a la liste : ");
         scanf("%s", new_word);
         // Ajouter le nouveau mot � la liste
        addWordToList(&head, new_word);
         // Afficher la liste mise � jour
         printf("\n la liste mise a jour \n");
         PrintfBidirectionalList(head);
         printf("\n*************************\n");
         printf("\n maintenant choisissez l'une de ces operations \n ");
         printf("\n***********sous menu**************\n");
         printf("\n 11: Afficher les listes des mots de la meme famille \n (Des mots formes a partir d\'autre mots en ajoutant une sous sequence de lettres) ");
         printf("\n 12: Afficher le participe passe avec \"ed\" et la forme \"ing\"");
         printf("\n 13: Afficher la sequence de mot formee par l\'ajout graduel d\'une lettre ");
         printf("\n 14: Afficer les listes des mots les plus proches lexicalement ");
         printf("\n 15: Afficher les listes des anagrammes ");
         printf("\n 16: Quitter\n");
         printf("\n Entrez votre choix : ");
         scanf("%d", &ch1);
         printf("\n \n");
         switch (ch1) {  //debut pour ch1

            case 11:
               generateWordFamilies(head);
               break;
            case 12:
               extractEnglishVerbs(head);
               break;
            case 13:
              printf("\n Sequence de mots formes par l\'ajout graduel d\'une lettre a la fois a gauche, a droite ou au milieu \n \n");
              findWordsFromList(head);
               break;
            case 14:
               printf("\n Les mots les plus proches lexicalement sont: \n");
               printSimilarWords(head);
               break;
            case 15:
               printf("\n les listes des anagrammes sont: \n");
               ListMaillon * head = createBidirectionalList();
               addWordToList(&head, new_word);
               extractAnagrams(head);
               break;
            case 16:
               printf("Au revoir !\n");
               return 0;

           default:
               printf("Choix invalide\n");

      }   //fin pour ch1



         break; //case2-->end


      case 3:
         printf("\n Vous avez choisi l'option 3\n");
         printf("\n*************************\n");
         mots_du_fichier();
        // Cr�er la liste doublement cha�n�e
         head = createBidirectionalList();
         char word_to_remove[100];
         printf("\n Entrez un mot a supprimer de la liste : ");
         scanf("%s", word_to_remove);
         printf("\n************************************************************************************************************************\n");
         // Supprimer le mot de la liste
         removeWordFromList(&head, word_to_remove);
         // Afficher la liste mise � jour
         printf("\n la liste mise a jour \n");
         PrintfBidirectionalList(head);
         printf("\n*************************\n");
         printf("\n maintenant choisissez l'une de ces operations \n ");
         printf("\n***********sous menu**************\n");
          printf("\n 17: Afficher les listes des mots de la meme famille \n (Des mots formes a partir d\'autre mots en ajoutant une sous sequence de lettres) ");
         printf("\n 18: Afficher le participe passe avec \"ed\" et la forme \"ing\"");
         printf("\n 19: Afficher la sequence de mot formee par l\'ajout graduel d\'une lettre ");
         printf("\n 20: Afficer les listes des mots les plus proches lexicalement ");
         printf("\n 21: Afficher les listes des anagrammes ");
         printf("\n 22: Quitter\n");
         printf("\n Entrez votre choix : ");
         scanf("%d", &ch2);
        printf("\n \n");
         switch (ch2) {  //debut pour ch2

            case 17:
               generateWordFamilies(head);

               break;
            case 18:
               printf("\n verb*ed*ing  \n");
               printf("\n*************************\n");
               extractEnglishVerbs(head);
               break;
            case 19:
              printf("\n Sequence de mots formes par l\'ajout graduel d\'une lettre a la fois a gauche, a droite ou au milieu \n \n");
              findWordsFromList(head);
               break;
            case 20:
               printf("\n Les mots les plus proches lexicalement sont: \n");
               printSimilarWords(head);
               break;
            case 21:
               printf("\n les anagrammes sont:  \n");
               ListMaillon * head = createBidirectionalList();
                removeWordFromList(&head, word_to_remove);
               extractAnagrams(head);
               break;
            case 22:
               printf("Au revoir !\n");
               return 0;

           default:
               printf("Choix invalide\n");
   } //fin pour ch2


         break; //case3-->end


      case 4:
         printf("Au revoir !\n");
         return 0; //case4-->end

      default:
         printf("Choix invalide\n");

   }  //fin pour choix


  return 0;
}





